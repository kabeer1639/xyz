﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication2
{
    public partial class Form1 : Form
    {
        int tht;
        int twd;
        public Form1()
        {
            InitializeComponent();
        }
        private void btnformtitle_Click(object sender, EventArgs e)
        {
            this.Text = "Welcome Form";
        }

        private void btnbackcolor_Click(object sender, EventArgs e)
        {
            Color mycolor = Color.FromArgb(125, 200, 200);
            this.BackColor = mycolor;
        }

        private void btnbackimage_Click(object sender, EventArgs e)
        {
            this.BackgroundImage = Image.FromFile(@"../../images/Desert.jpg");
        }

        private void btnsetopacity_Click(object sender, EventArgs e)
        {
            this.Opacity = 0.5;
        }

        private void btnrmvbackimage_Click(object sender, EventArgs e)
        {
            this.BackgroundImage = null;
        }

        private void btnrstopacity_Click(object sender, EventArgs e)
        {
            this.Opacity = 1;
        }

        private void btnsetsize_Click(object sender, EventArgs e)
        {
            tht = this.Height;
            twd = this.Width;
            this.Height = 600;
            this.Width = 600;
        }

        private void btnrstsize_Click(object sender, EventArgs e)
        {
            this.Height = tht;
            this.Width = twd;
        }

        private void btnform2_Click(object sender, EventArgs e)
        {
            Form2 frm = new Form2();
            frm.StartPosition = FormStartPosition.Manual;
            frm.Location = new Point(350, 300);
            //frm.Show();
            DialogResult res = frm.ShowDialog();

            if(res==DialogResult.OK)
                MessageBox.Show(frm.Controls["textbox1"].Text+" \nDialog Ok");
            else
                MessageBox.Show(frm.Controls["textbox1"].Text+" \nDialog Cancelled");
        }

        private void btnok_Click(object sender, EventArgs e)
        {

        }

        private void btnhideform_Click(object sender, EventArgs e)
        {
            Form2 frm1 = new Form2();
            frm1.Hide();
        }
    }
}
