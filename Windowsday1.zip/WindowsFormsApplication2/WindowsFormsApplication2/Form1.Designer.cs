﻿namespace WindowsFormsApplication2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnformtitle = new System.Windows.Forms.Button();
            this.btnbackcolor = new System.Windows.Forms.Button();
            this.btnbackimage = new System.Windows.Forms.Button();
            this.btnrmvbackimage = new System.Windows.Forms.Button();
            this.btnsetopacity = new System.Windows.Forms.Button();
            this.btnrstopacity = new System.Windows.Forms.Button();
            this.btnsetsize = new System.Windows.Forms.Button();
            this.btnrstsize = new System.Windows.Forms.Button();
            this.btnok = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.btnform2 = new System.Windows.Forms.Button();
            this.btnhideform = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnformtitle
            // 
            this.btnformtitle.Location = new System.Drawing.Point(30, 26);
            this.btnformtitle.Name = "btnformtitle";
            this.btnformtitle.Size = new System.Drawing.Size(115, 23);
            this.btnformtitle.TabIndex = 0;
            this.btnformtitle.Text = "Set Form Title";
            this.btnformtitle.UseVisualStyleBackColor = true;
            this.btnformtitle.Click += new System.EventHandler(this.btnformtitle_Click);
            // 
            // btnbackcolor
            // 
            this.btnbackcolor.Location = new System.Drawing.Point(30, 56);
            this.btnbackcolor.Name = "btnbackcolor";
            this.btnbackcolor.Size = new System.Drawing.Size(115, 23);
            this.btnbackcolor.TabIndex = 1;
            this.btnbackcolor.Text = "Set Backcolor";
            this.btnbackcolor.UseVisualStyleBackColor = true;
            this.btnbackcolor.Click += new System.EventHandler(this.btnbackcolor_Click);
            // 
            // btnbackimage
            // 
            this.btnbackimage.Location = new System.Drawing.Point(30, 86);
            this.btnbackimage.Name = "btnbackimage";
            this.btnbackimage.Size = new System.Drawing.Size(115, 23);
            this.btnbackimage.TabIndex = 2;
            this.btnbackimage.Text = "Set BackImage";
            this.btnbackimage.UseVisualStyleBackColor = true;
            this.btnbackimage.Click += new System.EventHandler(this.btnbackimage_Click);
            // 
            // btnrmvbackimage
            // 
            this.btnrmvbackimage.Location = new System.Drawing.Point(30, 116);
            this.btnrmvbackimage.Name = "btnrmvbackimage";
            this.btnrmvbackimage.Size = new System.Drawing.Size(115, 23);
            this.btnrmvbackimage.TabIndex = 3;
            this.btnrmvbackimage.Text = "Remove BackImage";
            this.btnrmvbackimage.UseVisualStyleBackColor = true;
            this.btnrmvbackimage.Click += new System.EventHandler(this.btnrmvbackimage_Click);
            // 
            // btnsetopacity
            // 
            this.btnsetopacity.Location = new System.Drawing.Point(30, 146);
            this.btnsetopacity.Name = "btnsetopacity";
            this.btnsetopacity.Size = new System.Drawing.Size(115, 23);
            this.btnsetopacity.TabIndex = 4;
            this.btnsetopacity.Text = "Set Opacity";
            this.btnsetopacity.UseVisualStyleBackColor = true;
            this.btnsetopacity.Click += new System.EventHandler(this.btnsetopacity_Click);
            // 
            // btnrstopacity
            // 
            this.btnrstopacity.Location = new System.Drawing.Point(30, 176);
            this.btnrstopacity.Name = "btnrstopacity";
            this.btnrstopacity.Size = new System.Drawing.Size(115, 23);
            this.btnrstopacity.TabIndex = 5;
            this.btnrstopacity.Text = "Reset Opacity";
            this.btnrstopacity.UseVisualStyleBackColor = true;
            this.btnrstopacity.Click += new System.EventHandler(this.btnrstopacity_Click);
            // 
            // btnsetsize
            // 
            this.btnsetsize.Location = new System.Drawing.Point(30, 206);
            this.btnsetsize.Name = "btnsetsize";
            this.btnsetsize.Size = new System.Drawing.Size(115, 23);
            this.btnsetsize.TabIndex = 6;
            this.btnsetsize.Text = "Set Size";
            this.btnsetsize.UseVisualStyleBackColor = true;
            this.btnsetsize.Click += new System.EventHandler(this.btnsetsize_Click);
            // 
            // btnrstsize
            // 
            this.btnrstsize.Location = new System.Drawing.Point(30, 236);
            this.btnrstsize.Name = "btnrstsize";
            this.btnrstsize.Size = new System.Drawing.Size(115, 23);
            this.btnrstsize.TabIndex = 7;
            this.btnrstsize.Text = "Reset Size";
            this.btnrstsize.UseVisualStyleBackColor = true;
            this.btnrstsize.Click += new System.EventHandler(this.btnrstsize_Click);
            // 
            // btnok
            // 
            this.btnok.Location = new System.Drawing.Point(206, 352);
            this.btnok.Name = "btnok";
            this.btnok.Size = new System.Drawing.Size(75, 23);
            this.btnok.TabIndex = 8;
            this.btnok.Text = "Ok";
            this.btnok.UseVisualStyleBackColor = true;
            this.btnok.Click += new System.EventHandler(this.btnok_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(206, 26);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 9;
            // 
            // btnform2
            // 
            this.btnform2.Location = new System.Drawing.Point(30, 265);
            this.btnform2.Name = "btnform2";
            this.btnform2.Size = new System.Drawing.Size(115, 23);
            this.btnform2.TabIndex = 10;
            this.btnform2.Text = "Open Form 2";
            this.btnform2.UseVisualStyleBackColor = true;
            this.btnform2.Click += new System.EventHandler(this.btnform2_Click);
            // 
            // btnhideform
            // 
            this.btnhideform.Location = new System.Drawing.Point(30, 295);
            this.btnhideform.Name = "btnhideform";
            this.btnhideform.Size = new System.Drawing.Size(115, 23);
            this.btnhideform.TabIndex = 11;
            this.btnhideform.Text = "Hide Form 2";
            this.btnhideform.UseVisualStyleBackColor = true;
            this.btnhideform.Click += new System.EventHandler(this.btnhideform_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(332, 408);
            this.Controls.Add(this.btnhideform);
            this.Controls.Add(this.btnform2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.btnok);
            this.Controls.Add(this.btnrstsize);
            this.Controls.Add(this.btnsetsize);
            this.Controls.Add(this.btnrstopacity);
            this.Controls.Add(this.btnsetopacity);
            this.Controls.Add(this.btnrmvbackimage);
            this.Controls.Add(this.btnbackimage);
            this.Controls.Add(this.btnbackcolor);
            this.Controls.Add(this.btnformtitle);
            this.Name = "Form1";
            this.Text = "Form2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnformtitle;
        private System.Windows.Forms.Button btnbackcolor;
        private System.Windows.Forms.Button btnbackimage;
        private System.Windows.Forms.Button btnrmvbackimage;
        private System.Windows.Forms.Button btnsetopacity;
        private System.Windows.Forms.Button btnrstopacity;
        private System.Windows.Forms.Button btnsetsize;
        private System.Windows.Forms.Button btnrstsize;
        private System.Windows.Forms.Button btnok;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button btnform2;
        private System.Windows.Forms.Button btnhideform;
    }
}

