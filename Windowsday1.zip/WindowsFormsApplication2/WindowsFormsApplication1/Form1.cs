﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        static int counter=0;
        static int k = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int result = 0;
            try
            {
                result = Int32.Parse(textBox1.Text) + Int32.Parse(textBox2.Text);
                textBox3.Text = result.ToString();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            comboBox1.SelectedIndex = 0;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(comboBox1.SelectedIndex>0)
            {
                label4.Text = comboBox1.Text;
            }
            comboBox1.Items.Add("Rajkot");
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (counter < 100)
            {
                label5.Text = counter.ToString();
                counter++;
            }
            else
            {
                this.Close();
            }
            pictureBox2.Image = imageList1.Images[k++%4];
        }
    }
}
