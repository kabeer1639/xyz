﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EMPForm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            comboBox1.SelectedIndex = 0;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string name = this.Controls["textBox1"].Text;
            string doj = this.Controls["dateTimePicker1"].Text;
            string city = this.Controls["comboBox1"].Text;
            string skills="";
            foreach (string item in listBox1.SelectedItems)
            {
                skills += item + ", ";
            }
            string experience = this.Controls["numericUpDown1"].Text;
            string mno = this.Controls["maskedTextBox1"].Text;
            string gender="";
            if(this.radioButton1.Checked)
            {
                gender = "Male";
            }
            else
            {
                gender = "Female";
            }
            string lang = "";
            if(this.checkBox1.Checked)
            {
                lang += "Hindi, ";
            }
            if (this.checkBox3.Checked)
            {
                lang += "English, ";
            }
            if (this.checkBox4.Checked)
            {
                lang += "Sanskrit, ";
            }
            if (this.checkBox5.Checked)
            {
                lang += "Gujarati";
            }
            string result = "Name: " + name + "\nDOJ: " + doj + "\nCity: " + city + "\nSkills: " + skills + 
                "\nExperience: "+experience+"\nMobile No: "+mno+"\nGender: "+gender+"Languages Known: "+lang;
            MessageBox.Show(result);
            richTextBox1.Text = result;
            richTextBox1.SaveFile(@"C:\Users\parpandy\Documents\Visual Studio 2015\Projects\WindowsFormsApplication2\EMPForm\emp.txt",RichTextBoxStreamType.PlainText);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox1.Text = " ";
            dateTimePicker1.Text = "";
            comboBox1.SelectedIndex = 0;
            listBox1.ClearSelected();
            maskedTextBox1.Text = "";
            radioButton1.Checked = false;
            radioButton2.Checked = false;
            checkBox1.Checked=false;
            checkBox3.Checked = false;
            checkBox4.Checked = false;
            checkBox5.Checked = false;
            numericUpDown1.Value = 0;
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
