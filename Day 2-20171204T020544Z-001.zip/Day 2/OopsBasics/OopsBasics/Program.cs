﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OopsBasics
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee emp = new Employee();
            emp.EmpId = 101;
            emp.Name = "Gauri";
            Console.WriteLine("EmpId:{0} Name:{1}",
                              emp.EmpId,emp.Name);
        }
    }
}
