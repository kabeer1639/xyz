﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MathLib
{
    public class MathClass
    {
        public static int Add(int number1, int number2)
        {
            return (number1 + number2);
        }
        public static int Sub(int number1, int number2)
        {
            return (number1 - number2);
        }
        public static int Mul(int number1, int number2)
        {
            return (number1 * number2);
        }
        public static int Div(int number1, int number2)
        {
            return (number1 / number2);
        }
    }
}
