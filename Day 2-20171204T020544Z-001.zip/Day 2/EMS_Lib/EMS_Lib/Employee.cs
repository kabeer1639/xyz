﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS_Lib
{
    public class Employee
    {
        public int EmployeeId;
        public string EmployeeName;
        public char Gender;
        public DateTime DateOfBirth;

        public void PrintDetails()
        {
            Console.WriteLine("ID:{0} Name:{1} Gender:{2} DOB:{3}",
                            EmployeeId,EmployeeName,Gender,DateOfBirth.ToShortDateString());
        } 
        public void SetData(int employeeId,string name, char gender,DateTime dateofbirth)
        {
            EmployeeId = employeeId;
            EmployeeName = name;
            Gender = gender;
            DateOfBirth = dateofbirth;
        }
    }
}
