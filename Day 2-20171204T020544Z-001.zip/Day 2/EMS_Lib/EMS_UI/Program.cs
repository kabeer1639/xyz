﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EMS_Lib;

namespace EMS_UI
{
    class Program
    {
        static Employee emp = null;
        static Employee[] emps = new Employee[2]; 
        static void Main(string[] args)
        {
            PrintMenu();
        }

        static void PrintMenu()
        {
            int choice = 0;
            do
            {
                Console.WriteLine("Please select your option.\n1. Set Employee Data\n2.Display Employee Data\n3.Add Employees\n4.Print All Details\n5.Exit\n6.Enter your choice:");
                choice = int.Parse(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        SetData();
                        Console.WriteLine("Employee Data Saved.");
                        break;
                    case 2:
                        PrintData();
                        Console.WriteLine("\n");
                        break;
                    case 3:
                        AddEmployees();
                        break;
                    case 4:
                        PrintAllEmployees();
                        break;
                    case 5:
                        break;
                    default:
                        Console.WriteLine("Invalid option selected.");
                        break;
                }
            } while (choice !=5);
            
        }
        static void SetData()
        {
            emp = new Employee();
            Console.WriteLine("Enter Employee ID");
            emp.EmployeeId = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter Employee Name");
            emp.EmployeeName =Console.ReadLine();
            Console.WriteLine("Enter Gender");
            emp.Gender =char.Parse(Console.ReadLine());
            Console.WriteLine("Enter Date Of Birth");
            emp.DateOfBirth = DateTime.Parse(Console.ReadLine());
        }

        static void PrintData()
        {
            emp.PrintDetails();
        }

         static void AddEmployees()
        {
            for (int i = 0; i < 2; i++)
            {
                SetData();
                emps[i] = emp;
            }
        }
        static void PrintAllEmployees()
        {
            foreach (Employee item in emps)
            {
                item.PrintDetails();
                Console.WriteLine();
            }
        }

       
    }
}
