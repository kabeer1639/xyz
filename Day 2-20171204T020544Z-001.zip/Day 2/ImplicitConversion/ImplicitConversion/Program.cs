﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TypeConversion
{
    class Program
    {
        static void Main(string[] args)
        {
            //Implicit Conversion
            int i = 10;
            double d = i;
            Console.WriteLine(d);

            //Explicit Conversion
            double sal = 10.25;
            int j = (int)sal;
            Console.WriteLine(j);
        }
    }
}
