﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Constructor
{
    class Employee
    {
        public int Empid;
        public string Name;
       
        //Default Constructor
        public Employee()
        {
            Empid = 1;
            Name = "NA";
        }

        //Parameterized Constructor
        public Employee(int id,string name)
        {
            Empid = id;
            Name = name;
        }
        //Methods

        public void Printdetails()
        {
            Console.WriteLine("EmpId:{0} Name:{1}",
                              Empid,Name);

        }
    }
}
