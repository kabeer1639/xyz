﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Constructors
{
    class Employee
    {

        public int EmpId;
        public string Name;

        //Default Constructor
        public Employee()
        {
            EmpId = 1;
            Name = "John";
        }

    }
}
