﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParameterTypeDemo
{
    class Utility
    {
        //Pass By Value
        public static int Add(int a, int b)
        {
            return (a + b);
        }
        public static void Swap(ref int a, ref int b)
        {
            int temp = a;
            a = b;
            b = temp;
        }
        // Out Keyword
        public static void Square(int number, out int result)
        {
            result = number * number;
        }
        // Params Keyword
        public static int Addition(params int[] numbers)
        {
            int sum = 0;
            for (int i = 0; i < numbers.Length; i++)
            {
                sum = sum + numbers[i];
            }
            return sum;
        }

        //Optional Keyword
        public static int Cube(int number=3)
        {
            return number * number * number;
        }

        //Named Keyword
        public static void Print(string name, int age)
        {
            Console.WriteLine(name);
            Console.WriteLine(age);
        }
    }
}

