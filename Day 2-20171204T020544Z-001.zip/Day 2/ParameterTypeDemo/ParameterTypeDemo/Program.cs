﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParameterTypeDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            #region Pass By Value
            //int i = 90;
            //int j = 80;
            //int result = Utility.Add(i, j);
            //Console.WriteLine(result);
            #endregion

            #region Pass By Reference

            // int i = 10;
            //int j = 20;
            //Console.WriteLine("Before Swap\ni: {0} j:{1}",i,j);

            //  Utility.Swap(ref i,ref j);
            // Console.WriteLine("After Swap\ni: {0} j:{1}", i, j);
            #endregion

            #region Out Keyword
            int i = 10;
            int result;
            Utility.Square(i,out result);
            Console.WriteLine(result);
            #endregion

              #region Params keyword 
            int res = Utility.Addition(1, 2, 3);
            Console.WriteLine(res);
            #endregion

            #region Optional Keyword

            int results = Utility.Cube(2);
            Console.WriteLine(res);
            #endregion
            
            #region Named Keyword
            Utility.Print(age: 22, name: "Gauri");
            #endregion
        }
    }
}
