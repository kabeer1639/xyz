﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SingleDimensionArray
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] arr = new int[] { 1, 2, 3, 4, 5, 6 };
            // for(int i=arr.Length-1;i>=0; i--)
            {
                //Console.WriteLine(arr[i]);
            }
            // for (int i=0; i<arr.Length;i=i+2)
            {
                //Console.WriteLine(arr[i]);
            }
            //foreach loop
            // foreach(int j in arr)
            {
                // Console.WriteLine(j);
            }



        }
    }
}