﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JaggedArray
{
    class Program
    {
        static void Main(string[] args)
        {
            int[][] table = new int[3][];
            table[0] = new int[4] { 0, 1, 2, 3 };
            table[1] = new int[3] { 2,4,7};
            table[2] = new int[2] { 2,3};
            for(int i=0; i<3;i++)
            {
                for(int j=0; j<table[i].Length;j++)
                {
                    Console.Write(table[i][j] + " ");
                }
                Console.WriteLine();
            }
        }
    }
}
