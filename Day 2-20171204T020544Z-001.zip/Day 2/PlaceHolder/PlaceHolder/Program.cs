﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PlaceHolder
{
    class Program
    {
        static void Main(string[] args)
        {
           
            Console.WriteLine(  "Enter the name");
            string name = Console.ReadLine();

            Console.WriteLine("Enter the age");
            int age = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter the designation");
            string des = Console.ReadLine();
            Console.WriteLine("Name:{0} Age:{1} Designation:{2}",
                              name,age,des); 

        }
    }
}
