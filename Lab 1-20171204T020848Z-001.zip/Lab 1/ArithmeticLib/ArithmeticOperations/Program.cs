﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArithmeticLib;
namespace ArithmeticOperations
{
    class Program
    {
        static void Main(string[] args)
        {
            public static int Add(int number1, int number2)

        {
            return (number1 + number2);
        }
        public static int Sub(int number1, int number2)
        {
            return (number1 - number2);
        }
        public static int Mul(int number1, int number2)
        {
            return (number1 * number2);
        }
        public static int Div(int number1, int number2)
        {
            return (number1 / number2);

        }
        public static int Mod(int number1, int number2)
        {
            return (number1 % number2);

        }
        public static double Addition(int number1, int number2)
        {
            return (number1 + number2);

        }
        public static double Subtraction(int number1, int number2)
        {
            return (number1 - number2);

        }
        public static double Mulitply(int number1, int number2)
        {
            return (number1 * number2);

        }
        public static double Division(int number1, int number2)
        {
            return (number1 / number2);

        }
        public static double Modulus(int number1, int number2)
        {
            return (number1 % number2);

        }
    }
}

}

