﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PartialTypes
{
    partial class Employee
    {
        public int EmpId { get; set; }
        public string EmpName { get; set; }
        public char Gender { get; set; }
        public double Salary { get; set; }
        public DateTime DateOfBirth { get; set; }
    }
}
