﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PartialTypes
{
     partial class Employee
    {
        public void PrintDetails()
        {
            Console.WriteLine("ID:{0} DateOfBrith:{1}", EmpId,DateOfBirth);
        }
    }
}
