﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ContructorChaning_Demo
{
    class Program
    {
        static void Main(string[] args)
        {  
            Employee emp = new Employee();
            //Defalut condtructor requirement
            // Console.WriteLine("ID:{0} Name:{1}",emp.ID,emp.Name);
            //Console.ReadLine();
            

        }
    }
}
