﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ContructorChaning_Demo
{
    class Employee : Person
    {
        public string Department { get; set; }
        public double Salary { get; set; }
        public Employee(string d,double s,int i,string n):base(i,n);
        {
          Department=d;
            Salary =s;
        }
    }
}
