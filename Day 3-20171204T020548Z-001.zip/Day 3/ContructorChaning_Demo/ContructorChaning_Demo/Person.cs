﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ContructorChaning_Demo
{
    class Person
    {
        //Property
        public int ID { get; set; }
        public string Name { get; set; }

        //Defalut Constructor
        public Person(int i,string n)
        {
            ID = i;
            Name = n;
        }
    }
}
