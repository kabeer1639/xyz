﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObjectInitializer
{
    class Program
    {
        static void Main(string[] args)
        {
            #region  Object Initializer
            Employee emp = new Employee
            {
                ID = 1, Name = "John"
            };
            #endregion

            #region Anonymous Type 

            var mark = new
            {
                Id = 101,
                Name = "Gauri"
            };
            #endregion



        }
    }
}
