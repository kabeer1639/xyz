﻿namespace OurSpace
{
    public class MyClass
    {

    }
}
namespace OurSpace.MySpace
{
    public class MyClass
    {

    }
}