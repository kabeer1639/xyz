﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OurSpace.MySpace;
namespace Namespace
{
    class Program
    {
        static void Main(string[] args)
        {
            //OurSpace.MySpace.MyClass obj = new OurSpace.MySpace.MyClass();
            //OurSpace.MyClass obj1 = new OurSpace.MyClass();

            MyClass mc = new MyClass();
            OurSpace.MyClass emp1 = new OurSpace.MyClass();
        }





    }
}
