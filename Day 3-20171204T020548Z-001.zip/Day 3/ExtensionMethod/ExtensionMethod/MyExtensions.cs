﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExtensionMethod
{
    public static class MyExtensions
    {
        public static bool isEven(this int value)
        {
            if (value % 2 == 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public static bool isOdd(this int value)
        {
            if (value % 2 != 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
