﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interface
{
    class Triangle : IShape //parent
    {
         //Implicit
      public void Area()
        {
            Console.WriteLine("Calculate Area");
        }

        //to invoke-Create object and call it
        
            //Explicit
        void IShape.Area()
        {

            Console.WriteLine("Area");
            //Cannot be called because Class method Area is private
        }
    }
}
