﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;


namespace PanDL
{
    class PanConfiguration
    { 

        private static string providerName;

    public static string ProviderName
    {
        get { return PanConfiguration.providerName; }
        set { PanConfiguration.providerName = value; }
    }
    private static string connectionString;

    public static string ConnectionString
    {
        get { return PanConfiguration.connectionString; }
        set { PanConfiguration.connectionString = value; }
    }

    static PanConfiguration()
    {
        providerName = ConfigurationManager.ConnectionStrings["panBookConnection"].ProviderName;
        connectionString = ConfigurationManager.ConnectionStrings["panBookConnection"].ConnectionString;

    }
}

}

