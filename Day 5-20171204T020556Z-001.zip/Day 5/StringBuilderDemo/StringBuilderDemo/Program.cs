﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringBuilderDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            string str = "Hello World 123";
            char[] c = str.ToCharArray();

            Console.WriteLine(str.Length);
            Console.WriteLine(str.ToUpper());
            foreach (char item in c)
            {
                if (char.IsDigit(item))
                {
                    throw new Exception("No digits allowed");
                }
            }

            string str = "Hello ,World, Bye, All";
            string[] words = str.Split(',');
            Console.WriteLine(words.Length);

            string str = "Hello ,World, Bye, All";
            int index =  str.IndexOf('y');
            Console.WriteLine(index);
        }
    }
}
