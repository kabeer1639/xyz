﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SingleCastDelegates
{
    class Program
    {
        static void Main(string[] args)
        {
            //MathClass mc = new MathClass();
            //int result = mc.Add(10, 20);
            //int result = mc.Sub(20, 10);

            MathClass mc = new MathClass();
            //Initialization 
            MathDel md = new MathDel(mc.Add);
            //Invoking a delegate
            int res = md.Invoke(10, 20);


            //If Static method-
            md += new MathDel(MathClass.Sub); //overloading takes place 

            //Invoke
            res = md.Invoke(10, 20);
            Console.WriteLine(res);




        }
    }
}
