﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericMethodDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            int n1 = 10, n2 = 20;
             string s1= "Hello";
            string s2 = "Bye";

            Utility obj = new Utility();
            
            //int datat type
            obj.Swap<int>(ref n1, ref n2);
            Console.WriteLine("N1:{0} N2:{1}",n1,n2);

            //string data type
            obj.Swap<string>(ref s1, ref s2);
            Console.WriteLine("S1:{0} S2:{1}", s1, s2);

        }
    }
}
