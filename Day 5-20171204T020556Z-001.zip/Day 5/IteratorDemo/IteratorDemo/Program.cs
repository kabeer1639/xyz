﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IteratorDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            DaysOFtheWeek dw = new DaysOFtheWeek();
            dw[0] = "Monday";
            dw[1] = "Tuesday";
            dw[2] = "Wednesday";
            dw[3] = "Thursday";
            dw[4] = "Friday";
            dw[5] = "Saturday";
            dw[6] = "Sunday";
            Console.WriteLine(dw[3]);
            foreach (string item in dw)
            {
                Console.WriteLine(item);
          
            }

        }
    }
}
