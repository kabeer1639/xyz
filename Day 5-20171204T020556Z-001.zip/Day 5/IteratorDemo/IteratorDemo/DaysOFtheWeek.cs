﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace IteratorDemo
{
    class DaysOFtheWeek : IEnumerable
    {
        string[] days =  new string[7];
         
        //INDEXER
        public string this[int a]
        {
            get
            {
                return days[a];
            }
            set
            {
                days[a] = value;
            }
        }

        public IEnumerator GetEnumerator()
        {
            foreach (string item in days)
            {
                yield return item;
            }            
        }
    }
}
