﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericListDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            //ArrayList but Generic
            List<Employee> empList = new List<Employee>();

            //Object Initializer
            empList.Add(new Employee { EmpId = 1, EmpName = "John" });
            empList.Add(new Employee { EmpId = 2, EmpName = "Katie" });

            //To print

            foreach (Employee item in empList)
            {
                if(item.EmpId==1)
                {
                    Console.WriteLine("Id:{0} Name:{1}",
                                      item.EmpId,item.EmpName);
                }

            }
            //another list

            List<int> number = new List<int>();
            number.Add(10);
            number.Add(20);
            number.Add(30);
            //Use CONTAINS to check if 20 is present in the list
            if(number.Contains(20))
            {
                Console.WriteLine("True");
            }
            else
            {
                Console.WriteLine("False");
            }
        }
    }
}
