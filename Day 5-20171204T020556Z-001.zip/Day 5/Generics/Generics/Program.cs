﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace Generics
{
    class Program
    {
        static void Main(string[] args)
        {
            //Collection
            Stack S = new Stack();
            S.Push(100);

            //Generic
            Stack<int> GS = new Stack<int>();
            GS.Push(100);

            Stack<string> gs = new Stack<string>();
            gs.Push("Gauri");

            //Generic stack class for storing Employee
            Stack<Employee> e = new Stack<Employee>();
            e.Push(new Employee
                {
                EmpId = 1,
                EmpName="John"
            });

            e.Push(new Employee
            {
                EmpId = 2,
                EmpName = "Katie"
            });
            foreach (Employee item in e)
            {
                Console.WriteLine("Id:{0} Name:{1}",
                                  item.EmpId,item.EmpName);
            }


        }
    }
}
