﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CollectionInitializer
{
    class Program
    {
        static void Main(string[] args)
        {
            //full syntax for single D 
            //int[] arr = new int[5] { 1, 2, 3, 4, 5 };

            //shortest syntax for singleD array
            //int[] numbers = { 1,2,3,4,5};

            //Generic list-Collection initializer
            //List<int> number = new List<int>() { 1, 2, 3, 4, 5 };

            //Generic list to store Employee object(Collection initializer which uses Object initializer code)

            List<Employee> emp = new List<Employee>
            {
                new Employee
                {
                    Id=1,Name="John"
                },
                new Employee
                {
                    Id=2,Name="Katie"
                }
            };
        }
    }
}
