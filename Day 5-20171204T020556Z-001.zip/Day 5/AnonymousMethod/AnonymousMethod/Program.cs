﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnonymousMethod
{
    delegate int AddDel(int num1, int num2);
    delegate int SquareDel(int n1);
    class Program
    {
        static void Main(string[] args)
        {
            //Anonymous Method Declaration 
            AddDel ad = delegate (int n1, int n2)
            {
                return (n1 + n2);
            };
            SquareDel sq = delegate (int n1)
           {
               return n1 * n1;
           };

            //Invoke
            int res = ad(10, 20);
            Console.WriteLine(res);

            res = sq(5);
            Console.WriteLine(res);
        }
    }
}
