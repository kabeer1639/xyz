﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace ComparingObjects
{
    class Employee : IComparable
    {
        //ICOMPARABLE 

        public int ID { get; set; } //Default sort will be done on ID 
        public string Name { get; set; }
        public double Salary { get; set; }

        public int CompareTo(object obj)

        {
            Employee emp = (Employee)obj; //Typecasting

            if (this.ID > emp.ID)
            {
                return 1;
            }
            else if (this.ID == emp.ID)
            {
                return 0;
            }
            else
            {
                return -1;


            }
        }
        //NESTED CLASSES(ALWAYS PRIVATE)

        //ICOMAPRER
        private class SortEmployeeNamebyAscendingHelper : IComparer
        {
            public int Compare(object x, object y)
            {
                Employee e1 = (Employee)x;
                Employee e2 = (Employee)y;

                return string.Compare(e1.Name, e2.Name);
            }
        }
        private class SortEmployeeNamebyDescendingHelper : IComparer
        {
            public int Compare(object x, object y)
            {
                Employee e1 = (Employee)x;
                Employee e2 = (Employee)y;

                return string.Compare(e2.Name, e1.Name);
            }
        }
        public static IComparer SortEmployeeNamebyAscending()
        {
            return (IComparer)new SortEmployeeNamebyAscendingHelper();
        }                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    
        public static IComparer SortEmployeeNamebyDescending()
        {
            return (IComparer)new SortEmployeeNamebyDescendingHelper();
        }
    }
}
