﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComparingObjects
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee[] empList =
           {
                new Employee
                {
                    ID= 200,Name = "John",Salary=14550.00
                },
                new Employee
                {
                    ID= 100,Name = "Katie",Salary=18550.00
                },
                new Employee
                {
                    ID= 300,Name = "Cathy",Salary=15550.00
                }
            };
            Console.WriteLine("Before Sorting:");

            foreach (Employee item in empList)
            {
                Console.WriteLine("ID:{0} Name:{1} Salary:{2}",
                                item.ID, item.Name, item.Salary);
            }


            #region IComparable Implementation

            Array.Sort(empList); //Sorting based on ID
            Console.WriteLine("After Sorting based on ID:");

            foreach (Employee item in empList)
            {
                Console.WriteLine("ID:{0} Name:{1} Salary:{2}",
                                item.ID, item.Name, item.Salary);
            }
            #endregion

            //Sorting based on Name= Asc and Desc : Use IComparer

            #region IComparer Implementation

            Array.Sort(empList, Employee.SortEmployeeNamebyAscending());
            Console.WriteLine("Ascending Order");
            foreach (Employee item in empList)
            {
                Console.WriteLine("ID:{0} Name:{1} Salary:{2}",
                                item.ID, item.Name, item.Salary);
            }

            Array.Sort(empList, Employee.SortEmployeeNamebyDescending());

            Console.WriteLine("");

            Console.WriteLine(" Descending Order");
            foreach (Employee item in empList)
            {
                Console.WriteLine("ID:{0} Name:{1} Salary:{2}",
                                item.ID, item.Name, item.Salary);
            }

            #endregion

           
            
            //Sorting based on Salary- Asc and Desc order
           


        }
    }
}
