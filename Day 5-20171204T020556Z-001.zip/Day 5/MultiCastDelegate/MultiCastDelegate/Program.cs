﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MultiCastDelegate
{
    class Program
    {
        static void Main(string[] args)
        {
            MathClass mc = new MathClass();
            //Initialization
            MathDel md = new MathDel(mc.Add);

            //If Static method-
            md += new MathDel(MathClass.Sub); //overloading takes place 

            md += new MathDel(MathClass.Mul);
            
            //Remove sub method 
            md -= new MathDel(MathClass.Sub);
            
            //Invoke
            md.Invoke(10, 20);
            Console.WriteLine();

        }
    }
}
