﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MultiCastDelegate
{
    //Declaration
    delegate void MathDel(int n1, int n2);
    class MathClass
    {
        public void Add(int num1, int num2)
        {
            int result = num1 + num2;
            Console.WriteLine(result);
        }
        public static void Sub(int num1, int num2)
        {
            int result = num1 - num2;
            Console.WriteLine(result);
        }
        public static void Mul(int num1, int num2)
        {
            int result = num1 * num2;
            Console.WriteLine(result);
        }
    }
}
