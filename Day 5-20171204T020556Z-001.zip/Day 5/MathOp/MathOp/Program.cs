﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MathOp
{
    class Program
    {
        static void Main(string[] args)
        {
            ////Console.WriteLine("Enter a number");
            ////int num = int.Parse(Console.ReadLine());
            ////double d =  Math.Sqrt(num);
            ////Console.WriteLine(Math.Round(d,2));

            //directly considering a number in range 0-10
            Random ran = new Random(0);
            int num = ran.Next(10);
            Console.WriteLine(num);

        }
    }
}
