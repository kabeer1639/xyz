﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LambdaExpressions
{
    delegate int AddDel(int n1, int n2);
    class Program
    {
        static void Main(string[] args)
        {
            //Delegate
            MathClass mc = new MathClass();
            MathDel md = new MathDel(mc.Add);
           int res=md.Invoke(10, 30);
            Console.WriteLine(res);

            //Anonymous Method
            AddDel  ad= delegate(int n1,int n2)
                {
                return n1 + n2;
            };
            int result = ad.Invoke(10,10);
            Console.WriteLine(result);

            //Lambda expression
            AddDel add = (x, y) => x + y;
            int r = add(10, 4);
            Console.WriteLine(r);
        }
    }
}
