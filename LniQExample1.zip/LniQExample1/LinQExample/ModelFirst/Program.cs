﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ModelFirst {
    class Program {
        static void Main(string[] args) {
            EntityModelContainer context = new EntityModelContainer();
            Bike multiStrada = new Bike() {
                Model = "R1200 GS",
                YearOfMake = 2018,
                Company = "BMW"
            };
            context.Bikes.Add(multiStrada);
            context.SaveChanges();
        }
    }
}
