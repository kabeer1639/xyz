﻿using System;
using System.Linq;
using System.Data.Entity;

namespace CodeFirstApproach {
    class CarDBContext : DbContext {
        public CarDBContext() : base("DBConString") {

        }
        public DbSet<Car> Cars { get; set; }
    }
}
