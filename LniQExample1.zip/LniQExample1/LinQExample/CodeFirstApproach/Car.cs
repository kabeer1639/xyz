﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Linq;

namespace CodeFirstApproach {
    class Car {
        [Key]
        public int CarID { get; set; }
        public string Company { get; set; }
        public int YearOfMake { get; set; }
        public string Model { get; set; }
    }
}
