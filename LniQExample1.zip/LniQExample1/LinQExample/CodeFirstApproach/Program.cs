﻿using System;
using System.Linq;

namespace CodeFirstApproach {
    class Program {
        static void Main(string[] args) {
            CarDBContext context = new CarDBContext();
            Car carObj = new Car() {
                Company = "Ford",
                YearOfMake = 2017,
                Model = "Endeavour"
            };
            context.Cars.Add(carObj);
            context.SaveChanges();
        }
    }
}
