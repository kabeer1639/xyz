﻿using System;
using System.Linq;

namespace LinQExample {
    class Program {
        static void Main(string[] args) {
            Training_WPFEntities context = new Training_WPFEntities();

            var result = from record in context.Tables
                         where record.EmpID == 1
                         select record;

            foreach(var r in result) {
                Console.WriteLine(r.FirstName);
            }

            //Inserting a Record
            //Table newEmp = new Table();
            //newEmp.EmpID = 6;
            //newEmp.FirstName = "Vishal";
            //newEmp.LastName = "Chauhan";
            //newEmp.Age = 22;
            //newEmp.Address = "Meerut";
            //context.Tables.Add(newEmp);
            //context.SaveChanges();

            //Deleting a Record
            //Table toBeDeleteed = (from record in context.Tables
            //                     where record.EmpID == 6
            //                     select record).FirstOrDefault();
            //context.Tables.Remove(toBeDeleteed);
            //context.SaveChanges();

            //Updating a Record
            Table toBeUpdated = (from record in context.Tables
                                  where record.EmpID == 1
                                  select record).FirstOrDefault();
            toBeUpdated.Address = "Pune";
            context.SaveChanges();
        }
    }
}
