﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization.Formatters.Soap;
using System.Xml.Serialization;
using System.IO;

namespace Serialization
{
    class Program
    {
        static Employee objEmp;
        const string strBinSer = "Binary";
        const string strSOAPSer = "SOAP";
        const string strXMLSer = "XML";
        static void Main(string[] args)
        {
            Console.WriteLine("---Demo Serialization---");
            Console.WriteLine("1.For Binary Serialization\n2.Binary Deserialization\n3.SOAP Serialization\n4.SOAP Deserialization\n5.XML Serialization\n6.XML Serialization");
            int choice;
            choice = Convert.ToInt32(Console.ReadLine());
            switch(choice)
            {
                case 1:
                    LoadEmployeeRecord();
                    Binary_Serialization();
                    break;
                case 2:
                    Binary_Deserialization();
                    break;
                case 3:
                    LoadEmployeeRecord();
                    Soap_Serialization();
                    break;
                case 4:
                    Soap_Deserialization();
                    break;
                case 5:
                    LoadEmployeeRecord();
                    XML_Serialization();
                    break;
                case 6:
                    XML_Deserialization();
                    break;
                default:
                    Console.WriteLine("Invalid Choice");
                    break;
            }
        }
        static void Binary_Serialization()
        {
            FileStream objFS = new FileStream(@"D:\M2_GauriDeshpande\Examples\Day 6\BinarySerialization\BB.txt",
                                                FileMode.Create, FileAccess.Write, FileShare.Read);
            BinaryFormatter objBinFormat = new BinaryFormatter();
            objBinFormat.Serialize(objFS, objEmp);
            objFS.Close();

        }
        static void Binary_Deserialization()
        {
            FileStream objFS = new FileStream(@"D:\M2_GauriDeshpande\Examples\Day 6\BinarySerialization\BB.txt",
                                                FileMode.Open,FileAccess.Read, FileShare.Read);
            BinaryFormatter objBinFormat = new BinaryFormatter();
            Employee objEmpBinFormat = objBinFormat.Deserialize(objFS) as Employee;
            DisplayEmployeeRecord(objEmpBinFormat, strBinSer);
        }

        static void Soap_Serialization()
        {
            FileStream objFS = new FileStream(@"D:\M2_GauriDeshpande\Examples\Day 6\BinarySerialization\SOAP.xml",
                                                FileMode.Create, FileAccess.Write, FileShare.Read);
            SoapFormatter objSoapFormat = new SoapFormatter();
            objSoapFormat.Serialize(objFS, objEmp);
            objFS.Close();
        }
        static void Soap_Deserialization()
        {
            FileStream objFS = new FileStream(@"D:\M2_GauriDeshpande\Examples\Day 6\BinarySerialization\SOAP.xml",
                                               FileMode.Open, FileAccess.Read, FileShare.Read);
            SoapFormatter objSoapFormat = new SoapFormatter();
            Employee objEmpSoapFormat = objSoapFormat.Deserialize(objFS) as Employee;
            DisplayEmployeeRecord(objEmpSoapFormat, strSOAPSer);
        }
        static void XML_Serialization()
        {
            FileStream objFS = new FileStream(@"D:\M2_GauriDeshpande\Examples\Day 6\BinarySerialization\XMLF.xml",
                                               FileMode.Create, FileAccess.Write, FileShare.Read);
            XmlSerializer objXMLSer= new XmlSerializer(typeof(Employee));
            objXMLSer.Serialize(objFS, objEmp);
            objFS.Close();
        }
        static void XML_Deserialization()
        {
            FileStream objFS = new FileStream(@"D:\M2_GauriDeshpande\Examples\Day 6\BinarySerialization\XMLF.xml",
                                              FileMode.Open, FileAccess.Read, FileShare.Read);
            XmlSerializer objXMLSer = new XmlSerializer(typeof(Employee));
            Employee objEmpXMLSer = objXMLSer.Deserialize(objFS) as Employee;
            DisplayEmployeeRecord(objEmpXMLSer, strXMLSer);

        }
        static void DisplayEmployeeRecord(Employee objEmployee,string strTypeOfSer)
        {
            Console.WriteLine("------Employee Info Using {0} Serialization-----",strTypeOfSer);
            Console.WriteLine("Id: " + objEmployee.Id);
            Console.WriteLine("Name: " + objEmployee.Name);
            Console.WriteLine("DesignationId: " + objEmployee.DesignationId);
            Console.WriteLine("DepartmentId: " + objEmployee.DepartmentId);
        }
        static void LoadEmployeeRecord()
        {
            objEmp = new Employee
            {
                Id = 101,
                Name = "Suraj",
                DepartmentId = 201,
                DesignationId = 301
            };
        }
    }
}
