﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IGATEPATNI.Winforms.Demo05
{
    public class Employee
    {
        public int EmployeeID { get; set; }
        public string EmployeeName { get; set; }
        public string Location { get; set; }
    }
}
