﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;

namespace PersonInfo
{
    [AttributeUsage(AttributeTargets.Method|AttributeTargets.Property|AttributeTargets.Field,AllowMultiple =true)]

    
    public class CPerson : Attribute
    {
        #region Fields
        public string _name;
        public int _age;
        public double _salary;
        #endregion

        #region Property
        public string NAME { get {return _name;} set {_name = value; } }
        public int AGE { get {return _age;} set {_age = value; } }
        public double SALARY { get {return _salary; } set { _salary = value; } }
        #endregion

       
        #region Method
        public void ShowDetails()
        {
            Console.WriteLine("Name : {0}\nAge : {1}, Salary : {2}",NAME,AGE,SALARY);
        }
        #endregion
        #region Constructor
        #endregion
    }


}
