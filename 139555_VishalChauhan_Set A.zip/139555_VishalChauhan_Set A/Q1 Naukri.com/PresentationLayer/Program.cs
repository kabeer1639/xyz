﻿//**********************************************************************************************************//
// File Name : - Presentation Layer
// Developer : - Vishal Chauhan
// Date      : - 05/12/2017
//**********************************************************************************************************//

using System;
using System.Collections.Generic;
using Enitities;
using UtilityLayer;
using BusinessAccessLayer;
using System.IO;
using DataAccessLayer;

namespace PresentationLayer
{
    class Program
    {
        static void Main(string[] args)
        {

            try
            {
                int choice = 0;
                do
                {
                    PrintMenu();
                    Console.WriteLine("Enter your choice:");
                    choice = Convert.ToInt32(Console.ReadLine());
                    switch (choice)
                    {
                        case 1:
                            AddCustomer();
                            break;

                        case 2:
                            DisplayCustomer();
                            break;

                        case 3:
                            SearchCustomer();
                            break;
                        case 4:
                            //Deserilization Before Exit
                            FileStream fileStream = new FileStream("d:\\ser.dat", FileMode.Open);
                            List<Customer> newlist = new List<Customer>(CustomerOperations.DeserializeList<Customer>(fileStream));
                            Console.WriteLine("\n\t\t DESERIALIZED DATA ");
                            Console.WriteLine("----------------------------------------------------------");
                            foreach (Customer item in newlist)
                            {
                                Console.WriteLine("Customer Name : {0}\nCustomer Qualification: {1} \nPhone Number : {2}\nAddress : {3}\nCity : {4}\nDesignation : {5}\nDate of Birth : {6}\nMarital Status (M-Married / U-Unmarried) : {7}\n\n",
                                   item.NAME, item.QUALIFICATION, item.PHN_NUM, item.ADDRESS, item.CITY, item.DESIGNATION, item.DOB, item.MARITAL_STATUS);

                            }
                            break;
                        default:
                            Console.WriteLine("Invalid choice.Please try again");
                            break;
                    }
                } while (choice != 4);
            }
            catch (FormatException ex)
            {

                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {

                Console.WriteLine(ex.Message);
            }
        }
        static void PrintMenu()
        {
            Console.WriteLine("-------------------------------------------------------------------------"); 
            Console.WriteLine("\t\t\tWelcome to Naukri.com");
            Console.WriteLine("-------------------------------------------------------------------------");
            Console.WriteLine("\n1.Add Data");
            Console.WriteLine("\n2.Display Users");
            Console.WriteLine("\n3.Search Users");
            Console.WriteLine("\n4.Exit OR View Deserialized Data\n");
            Console.WriteLine("--------------------------------------------------------------------------\n");
        }

        //Method to add new Customer
        static void AddCustomer()
        {
            try
            {
                //Create object of Entity class
                Customer obj = new Customer();

                //Store all product information
                Console.WriteLine("Enter Customer Name : ");
                obj.NAME = Console.ReadLine();
                Console.WriteLine("Enter Qualification (BE/ME/MCA): ");
                obj.QUALIFICATION = Console.ReadLine();
                Console.WriteLine("Enter Mobile Number : ");
                obj.PHN_NUM = Convert.ToDecimal(Console.ReadLine());
                Console.WriteLine("Enter Address : ");
                obj.ADDRESS = Console.ReadLine();
                Console.WriteLine("Enter City (Mumbai/Pune/Chennai/Bangalore): ");
                obj.CITY = Console.ReadLine();
                Console.WriteLine("Enter Designation (Manager/Deputy Manager/Assistant Manager): ");
                obj.DESIGNATION = Console.ReadLine();
                Console.WriteLine("Enter Date of Birth :");
                obj.DOB = DateTime.Parse(Console.ReadLine());
                Console.WriteLine("Enter Marital Status (M - Married / U - Unmarried) : ");
                obj.MARITAL_STATUS = Console.ReadLine();

                //Create obj of Business Layer
                CustomerBL cbl = new CustomerBL();
                bool result = cbl.AddCustomer(obj);
                //Console.WriteLine(result);
                //Print Message if data added successfully
                if (result)
                {
                    Console.WriteLine("\nCustomer Added Successfully");
                }

            }
            catch (FormatException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        //Method to display Customer
        static void DisplayCustomer()
        {
            try
            {
                CustomerBL cbl = new CustomerBL();
                List<Customer> list = cbl.DisplayCustomer();
                Console.WriteLine("\n\n\t\t Details for all Users are: \n\n");
                foreach (Customer item in list)
                {

                    Console.WriteLine("Customer Name : {0}\nCustomer Qualification: {1} \nPhone Number : {2}\nAddress : {3}\nCity : {4}\nDesignation : {5}\nDate of Birth : {6}\nMarital Status (M-Married / U-Unmarried) : {7}\n\n",
                                    item.NAME, item.QUALIFICATION, item.PHN_NUM, item.ADDRESS, item.CITY, item.DESIGNATION, item.DOB, item.MARITAL_STATUS);

                }
                Console.WriteLine();

            }
            catch (SystemException ex)
            {

                Console.WriteLine(ex.Message);
            }
        }



        //Method to search Customer
        static void SearchCustomer()
        {
            try
            {
                Console.WriteLine("Enter Designation");
                string designation = Console.ReadLine();

                CustomerBL cbl = new CustomerBL();
                List<Customer> custlist = new List<Customer>(cbl.SearchCustomer(designation));
                
                if (custlist.Count>0)
                {
                    Console.WriteLine("\n\n\t\tAll Users with {0} designation are:\n\n",designation);
                    foreach (Customer item in custlist)
                    {
                        Console.WriteLine("Customer Name : {0}\nCustomer Qualification: {1} \nPhone Number : {2}\nAddress : {3}\nCity : {4}\nDesignation : {5}\nDate of Birth : {6}\nMarital Status (M-Married / U-Unmarried) : {7}\n\n",
                                  item.NAME, item.QUALIFICATION, item.PHN_NUM, item.ADDRESS, item.CITY, item.DESIGNATION, item.DOB, item.MARITAL_STATUS);
                    }
                }
                else
                {
                    Console.WriteLine("No such User found.");
                }
            }
            catch (FormatException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }



    }
}