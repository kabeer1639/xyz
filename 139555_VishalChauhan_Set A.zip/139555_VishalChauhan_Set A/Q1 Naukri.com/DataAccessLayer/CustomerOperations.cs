﻿//**********************************************************************************************************//
// File Name : - Data Access Layer
// Developer : - Vishal Chauhan
// Date      : - 05/12/2017
//**********************************************************************************************************//

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Enitities;
using UtilityLayer;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;

namespace DataAccessLayer
{
    //Data Access Layer Class
    public class CustomerOperations
    {
        public static List<Customer> customerList = new List<Customer>();

        //Method to add new Customer
        public bool AddCustomer(Customer cobj)
        {
            bool result = false;
            try
            {
                customerList.Add(cobj);
                result = true;
                SerializeData(customerList);
                
            }
            catch (CustomerException)
            { 
                throw;
            }
            return result;
        }

        //Method to display all the Customers
        public List<Customer> DisplayCustomer()
        {
            return customerList;
        }

        //Method to search Customer
        public List<Customer> SearchCustomer(string customerDesignation)
        {
           // Customer cobj = null;
           List<Customer> newlist = new List<Customer>();
            foreach (Customer item in customerList)
            {
                if (item.DESIGNATION == customerDesignation)
                {
                    newlist.Add(item);
                }
            }
            return newlist;
        }

        //Serialization of Data 
        private static void SerializeData(List<Customer> e)
        {
            FileStream fileStream = new FileStream("d:\\ser.dat", FileMode.Create);
            BinaryFormatter binaryFormatter = new BinaryFormatter();
            foreach (Customer item in e)
            {
                binaryFormatter.Serialize(fileStream, item);
            }
            fileStream.Close();
        }

        //Deserialization of Data
        public static ICollection<Student> DeserializeList<Student>(FileStream fs)
        {
            BinaryFormatter bf = new BinaryFormatter();
            List<Student> list = new List<Student>();
            while (fs.Position != fs.Length)
            {
                //deserialize each object in the file
                var deserialized = (Student)bf.Deserialize(fs);
                //add individual object to a list
                list.Add(deserialized);
            }
            //return the list of objects
            return list;
        }
    }
}
