﻿//**********************************************************************************************************//
// File Name : - Utility Layer or Exception Hnadling Layer
// Developer : - Vishal Chauhan
// Date      : - 05/12/2017
//**********************************************************************************************************//

using System;

namespace UtilityLayer
{
    //Customer Exception Class
   public class CustomerException : ApplicationException
       {

        //Default Constructor
        public CustomerException()
        { }

        //Parameterized Constructor which take one string parameter
        public CustomerException(string message) : base(message)
        {
        }

        //Parameterized Constructor which takes two string parameter
        public CustomerException(string message, Exception innerException) : base(message, innerException)
        { }

    }
}
