﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
namespace CodeFirstApproach
{
    class Car
    {
        [Key]

        public int CarID { get; set; }


        public string Company {get; set; }

        public int YearofMake { get; set; }


        public string Model { get; set; }





    }
}
