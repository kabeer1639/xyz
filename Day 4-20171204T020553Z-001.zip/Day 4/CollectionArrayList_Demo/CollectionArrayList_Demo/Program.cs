﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace CollectionArrayList_Demo
{
    class Program
    {
        static void Main(string[] args)
        {
            ArrayList arr = new ArrayList();
            arr.Add(10.25);
            arr.Add(100);
            arr.Add("Gauri");
            arr.Add('F');
            // capacity increases- default capacity-4
            arr.Add(2344);
            Console.WriteLine("Count :{0} Capacity : {1}",arr.Count, arr.Capacity);
            Console.WriteLine();
            arr.Remove("Gauri");
            Console.WriteLine();
            foreach (object item in arr)
            {
                Console.WriteLine(item);
            }
            Console.WriteLine();
            arr.Add(10.25);
            Console.WriteLine(arr.Count);
            Console.WriteLine();
            arr.Remove(10.25);
            foreach (object item in arr)
            {
                Console.WriteLine(item);
            }

            Console.WriteLine();
            arr.Insert(1, "Gauri");
            foreach (object item in arr)
            {
                Console.WriteLine(item);
            }
            Console.WriteLine();
            arr.RemoveRange(1, 3);
            foreach (object item in arr)
            {
                Console.WriteLine(item);
            }
            Console.WriteLine();
            Console.WriteLine(arr.Count);

            Console.WriteLine();
            arr.Reverse();
            foreach (object item in arr)
            {
                Console.WriteLine(item);
            }
            //arr.Sort();
            //foreach (object item in arr)
            //{
                //Console.WriteLine(item);
            //}

        }
    }
}
