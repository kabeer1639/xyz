﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace CollectionStack_Demo
{
    class Program
    {
        static void Main(string[] args)
        {
            Stack s = new Stack();
            s.Push(100); //inserts
            s.Push(10.25);
            s.Push("Gauri");
            s.Push('F');
            Console.WriteLine(s.Count); //prints elements in the stack
            foreach (object item in s)
            {
                Console.WriteLine(item);
            }

            Console.WriteLine();
            Console.WriteLine( s.Pop()); //removes
            Console.WriteLine();
            Console.WriteLine(s.Peek()); //displays the topmost element in the stack



        }
    }
}
