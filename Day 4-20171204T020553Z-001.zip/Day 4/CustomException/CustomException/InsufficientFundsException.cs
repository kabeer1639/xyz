﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomException
{
   public class InsufficientFundsException : ApplicationException
    {
        public InsufficientFundsException()
        {}
        public InsufficientFundsException(string message) : base(message) //consructor chaining
        {}
        public InsufficientFundsException(string message, Exception innerException) : base(message,innerException)
        {}
    }
}
