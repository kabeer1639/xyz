﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
namespace CollectionQueue_Demo
{
    class Program
    {
        static void Main(string[] args)
        {
            Queue q = new Queue();
            q.Enqueue(100);
            q.Enqueue(10.25);
            q.Enqueue("Gauri");
            q.Enqueue('G');
            Console.WriteLine(q.Count);
            Console.WriteLine();
            Console.WriteLine(q.Dequeue());
            Console.WriteLine(q.Peek());
            foreach (object item in q)
            {
                Console.WriteLine(item);
            }

        }
    }
}
