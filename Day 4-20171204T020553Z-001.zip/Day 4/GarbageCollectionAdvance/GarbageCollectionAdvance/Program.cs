﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GarbageCollectionAdvance
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee emp = new Employee();
            //Console.WriteLine(GC.GetGeneration(emp));
            // GC.Collect();
            // Console.WriteLine(GC.GetGeneration(emp));
            //emp = null;
            //GC.Collect();
            //Console.WriteLine(GC.GetGeneration(emp));
            //GC.WaitForPendingFinalizers();
            //
            Console.WriteLine("Hello");


        }
    }
}
