﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;


namespace GarbageCollectionAdvance
{
    class Employee : IDisposable
    {
        //~Employee()
        // {
        //Thread.Sleep(5000);




        //}
        void IDisposable.Dispose()
        {
           Console.WriteLine("Destructor");
        }
    }
}
