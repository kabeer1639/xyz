﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExceptionHandling
{
    class Program
    {
        static void Main(string[] args)
        {
            int result = 0;
            try
            {
                int i = 10;
                int j = 10;
                result = i / j;
                
            }
            catch(DivideByZeroException ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
                {
                Console.WriteLine(result);

            }
        }
    }
}
