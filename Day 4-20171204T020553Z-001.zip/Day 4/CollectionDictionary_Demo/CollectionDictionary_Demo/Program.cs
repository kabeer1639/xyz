﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace CollectionDictionary_Demo
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
            Hashtable hash = new Hashtable();
            hash.Add(1,"Gauri");
            hash.Add('a',100);
            Console.WriteLine(hash.Count);
            // foreach (DictionaryEntry item in hash)
            //{
            // Console.WriteLine(item.Key);
            //Console.WriteLine(item.Value);
            //}
            
            Another syntax
            var Keys = hash.Keys;
            foreach (var item in Keys)
            {
                Console.WriteLine(hash[item]);
            }
            */
            SortedList sort = new SortedList();
            sort.Add(1,100);
            sort.Add(5,"Gaur");
            sort.Add(3,'G');
            sort.Add(2,10.25);
            sort.Add(4,242355);
            foreach (DictionaryEntry item in sort)
            {
               
                Console.WriteLine(item.Value);
            }
        }
    }
}
