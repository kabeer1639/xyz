﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GarbageCollection
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee emp = new Employee();
            // Console.WriteLine(GC.MaxGeneration);
            Console.WriteLine(GC.GetGeneration(emp));
            GC.Collect();
            Console.WriteLine(GC.GetGeneration(emp));
            GC.Collect();
            Console.WriteLine(GC.GetGeneration(emp));
            emp = null;
            GC.Collect();
            Console.WriteLine(GC.GetGeneration(emp));

        }
    }
}
