﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Event
{
    public delegate void AccountHolder();  
    class RBI
    {
        int _balance;
        public event AccountHolder OverBalance;
        public event AccountHolder UnderBalance;

        public RBI(int balance)
        {
            _balance = balance;
        }
 
        public void Deposit(int deposit)
        {
            int result = _balance + deposit;
            if(result > 1000000)
            {
                PayTax();
                //TODO: Complete code related to deposit transaction
            } 
        }
        public void Withdraw(int withdraw)
        {
            int result = _balance -withdraw;
            if (result > 500)
            {
                Penalty();
            }
        }

        public void PayTax()
        {
            OverBalance();
        }
        public void Penalty()
        {
            UnderBalance();
        }
    }
}
