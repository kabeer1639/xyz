﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Event
{
    class AxisBank
    {
        static void Main(string[] args)
        {
            RBI objRBI = new RBI(500000);
            objRBI.OverBalance += new AccountHolder(AxisPolicy.PayTax);
            objRBI.UnderBalance += new AccountHolder(AxisPolicy.Penalty);
            objRBI.Withdraw(499600);

        }
    }         static class AxisPolicy
        {
            public static void PayTax()
            {
                Console.WriteLine("Axis Bank:PAy Tax");
            }
            public static void Penalty()
            {
                Console.WriteLine("Axis Bank:Penalty");
            } 
        }

    }

