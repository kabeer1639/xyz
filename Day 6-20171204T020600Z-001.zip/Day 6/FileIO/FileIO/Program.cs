﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;


namespace FileIO
{
    class Program
    {
        static void Main(string[] args)
        {
            //FileStream_StramWriterDemo();
            // StreamReader_Demo();
            // StreamReader_Demo
            // File_Demo();
            //FileMove_Demo();
            //FileInfo_Demo();
            //Directory_Demo();
            //Directory_GetFiles_Demo();
            // Directory_GetFileName_Demo();
            Path_Demo();

        }
        static void FileStream_StramWriterDemo()
        {
            Console.WriteLine("CREATE FILE");
            FileStream objFs = new FileStream(@"D:\FileIODemos\DemoFile.txt",
                FileMode.Create,FileAccess.Write,FileShare.Read);
            StreamWriter objSw = new StreamWriter(objFs);
            objSw.WriteLine("This is File Demo.");
            objSw.Flush();
            objSw.Close();
            objFs.Close();

            bool filecreated= File.Exists(@"D:\FileIODemos\DemoFile.txt");
            if(filecreated==true)
            {
                Console.WriteLine("File Created Successfully.");
            }
        }
        static void StreamReader_Demo()
        {
            Console.WriteLine("File Create Demo using File Class.");
            FileStream objFs = new FileStream(@"D:\FileIODemos\DemoFile.txt",
                FileMode.Open, FileAccess.Read,FileShare.Read);
            StreamReader objSr = new StreamReader(objFs);
            Console.WriteLine(objSr.ReadToEnd());
            objSr.Close();
            objFs.Close();
        }
        static void File_Demo()
        {
            Console.WriteLine("File Create Demo using File Class.");
            FileStream objFs = File.Create(@"D:\FileIODemos\DemoFile1.txt");
            if (objFs != null)
            {
                Console.WriteLine("File Created Successfully");
            }
        }
        static void FileMove_Demo()
        {

            File.Move(@"D:\FileIODemos\DemoFile1.txt", @"D:\FileIODemos\subfolder\DemoFile1.txt");
            bool filemove = File.Exists(@"D:\FileIODemos\subfolder\DemoFile1.txt");
            if(filemove== true)
            {
                Console.WriteLine("File Moved Succssfully.");
            }
        }         
        static void FileInfo_Demo()
        {
            FileInfo objFi = new FileInfo(@"D:\FileIODemos\DemoFile2.txt");

            FileStream objFs = objFi.Create();
            if (objFs != null)
            {
                Console.WriteLine("File Created Successfully");
            }
            //objFi.Delete();
        }
        static void Directory_Demo()
        {
            DirectoryInfo objDi = Directory.CreateDirectory(@"D:\FileIODirectory");
            if(objDi.Exists)
            {
                Console.WriteLine("Directory created successfully");
            }
        }
        static void Directory_GetFiles_Demo()
        {
            string[] strFiles = Directory.GetFiles(@"D:\FileIODirectory");
            Console.WriteLine("List of Files from Directory:");
            foreach (var strFile in strFiles)
            {
                
                Console.WriteLine(strFile);
            }
        }
        static void Directory_GetFileName_Demo()
        {
            string[] strFiles = Directory.GetFiles(@"D:\FileIODirectory");
            Console.WriteLine("List of File Names from Directory:");
            foreach (var strFile in strFiles)
            {
                string strFilename = Path.GetFileName(strFile);
                Console.WriteLine(strFilename);
            }
        }
        static void Path_Demo()
        {
            string strFile = @"D:\FileIODirectory\MyFile.txt";

            Console.WriteLine("List of File Names from Path:");
            string strFilename = Path.GetFileNameWithoutExtension(strFile);
            Console.WriteLine(strFilename);

            Console.WriteLine("File Extensions");
            string strFileextension = Path.GetExtension(strFile);
            Console.WriteLine(strFileextension);

            Console.WriteLine("File Extensions");
            string strDirname = Path.GetDirectoryName(strFile);
            Console.WriteLine(strDirname);

            Console.WriteLine("List of invalid path characters");
            char[] invalidpathchars = Path.GetInvalidPathChars();
            foreach (var invalidpathchar in invalidpathchars)
            {
                Console.WriteLine(invalidpathchar + ",");
            }
        }

    }
}

