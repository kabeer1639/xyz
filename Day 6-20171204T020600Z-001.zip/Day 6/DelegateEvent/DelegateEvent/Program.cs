﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace DelegateEvent
{
    class Program
    {
        //Declare simle delegate
        delegate int MyDelegate(int a, int b);
        //Declare Delegate for chaining
        delegate void MyDelAnon(string str);
        static void Main(string[] args)
        {
            //Initialize simple delegate
            MyDelegate objmyDel = new MyDelegate(Add);
            int resultAdd = objmyDel.Invoke(10, 20);
            Console.WriteLine("Addition is:"+resultAdd);
            Console.WriteLine("----------------------");
            
            //Asynchronous Delegate
            Console.WriteLine("Asynchronous Delegate");
            MyDelegate objAnon = new MyDelegate(Sub);
            IAsyncResult objIAR = objAnon.BeginInvoke(20, 10, null, null);

            MyDelegate objDel2 = new MyDelegate(Add);
            int resultAdd2 = objDel2.Invoke(30, 30);
            Console.WriteLine("Addition is inside code block:" +resultAdd2);
            Console.WriteLine("------------------------");


            int resAsync = objAnon.EndInvoke(objIAR);
            if (objIAR.IsCompleted)
            {
                Console.WriteLine("Subtraction is :" + resAsync);
            }
            Console.WriteLine("------------------------");

            Console.WriteLine("Multicast Delegate");
            //MultiCAst Delegate
            MyDelegate objMultiDel;
            objMultiDel = objmyDel;
            objMultiDel += objDel2;

            int res = objMultiDel.Invoke(40, 20);
            Console.WriteLine("Val is: " +res);

            //For reading returned values from multicast delegate
            Delegate[] objInvokeList = objMultiDel.GetInvocationList();
            for(int i=0; i<objInvokeList.Length; i++)
            {
                MyDelegate objDelNew = (MyDelegate)objInvokeList[i];
                Console.WriteLine("Value from multicast delegate :",
                    +objDelNew(20,10));
            }
            Console.WriteLine("--------------------------");
            //Anonymous Delegate
            MyDelAnon objDelAnon = delegate (string myStr)
            {
                Console.WriteLine(myStr);
            };
            //Call Anonymous Delegate
            objDelAnon("Hello");
        }
        static int Add(int a,int b)
            {
            int res = a + b;
            return res; 
            }

        static int Sub(int a, int b)
        {
            int res = a - b;
            Thread.Sleep(3000);
            return res;
        }

        static int Mul(int a, int b)
        {
            int res = a * b;
            return res;
        }

        static int Div(int a, int b)
        {
            int res = a / b;
            return res;
        }
        


    }
}
