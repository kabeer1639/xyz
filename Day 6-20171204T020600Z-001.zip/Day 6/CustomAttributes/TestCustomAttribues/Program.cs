﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestCustomAttribues
{
    class Program
    {
        static void Main(string[] args)
        {
            MemberInfo mi = typeof(Account);
            object[] attributes = mi.GetCustomAttributes(typeof(ProgrammerInfo), false);
            foreach (object item in attributes)
            {
                ProgrammerInfo PgInfo = (ProgrammerInfo)item;
                Console.WriteLine("Programmer ID: " + PgInfo.Id.ToString());
                Console.WriteLine("Programmer Name: " + PgInfo.Name.ToString());
                Console.WriteLine("Date Created: " + PgInfo.Datecreated.ToString());
            }
            Console.ReadLine();

        }
    }
}
