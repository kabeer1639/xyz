﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomAttributes
{
    class ProgrammerInfo:Attribute
    {
        int _Id;
        string _name;
        string _datecreated; 

        public ProgrammerInfo(int Id, string Name, string Datecreated)
        {
            this._Id = Id;
            this._name = Name;
            this._datecreated = Datecreated;
        }
        public int Id
        {
            get { return _Id; }
            set { _Id = value; }
        }
        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }
        public string Datecreated
        {
            get { return _datecreated; }
            set { _datecreated = value; }
        }
    }
}
