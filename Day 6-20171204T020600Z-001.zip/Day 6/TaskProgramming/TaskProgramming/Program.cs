﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace TaskProgramming
{
    class Program
    {
        static void Main(string[] args)
        {
//            FourWaystocreateBasicClass();
            AddingTaskState_Fourways();
        }

        static void FourWaystocreateBasicClass()
        {
            //use and action delegate and named method
            Task task1 = new Task(new Action(printMessage));

            //use anonymous method
            Task task2 = new Task(delegate
            {
                printMessage();
            });

            //use a lambda expression and named method
            Task task3 = new Task(() => printMessage());

            //use a lambda expression and anonymous method
            Task task4 = new Task(() =>
            {
                printMessage();
            });

            task1.Start();
            task2.Start();
            task3.Start();
            task4.Start();

            Console.WriteLine("Main Method Complete");
            Console.ReadLine();

        }
        static void printMessage()
        {
            Console.WriteLine("hello world");
        }
        static void printMessage(object message)
        {
            Console.WriteLine("Message : {0}", message);
        }
        static void AddingTaskState_Fourways()
        {
            //use and action delegate and named method
            Task task1 = new Task(new Action<object>(printMessage), "First Task");

            //use anonymous delegate
            Task task2 = new Task(delegate (object obj)
            {
                printMessage(obj);

            }, "Second Task");

            //use a lambda expression and named method
            //note that parameters to a lambda dont need 
            //to be quoted if there is only one parameter
            Task task3 = new Task((obj) => printMessage(obj), "Third Task");

            //use a lambda expression and anonymous method
            Task task4 = new Task((obj) =>
            {
                printMessage(obj);
            }, "Fourth Task");

            task1.Start();
            task2.Start();
            task3.Start();
            task4.Start();

            Console.WriteLine("Main Method Complete");
            Console.ReadLine();
        }
    }
}
