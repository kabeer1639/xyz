﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;

namespace Reflection
{
    class Program
    {
        static void Main(string[] args)
        {


            Assembly objAssembly = Assembly.LoadFrom(@"D:\M2_GauriDeshpande\Examples\Day 1\MathLib.dll");
            //System.Type type = typeof(SampleReflection);
            System.Type type = objAssembly.GetType("MathLib.MathClass");

            MethodInfo[] methods = type.GetMethods();
            PropertyInfo[] properties = type.GetProperties();
            FieldInfo[] fields = type.GetFields();
            Console.WriteLine("{0} class has following methods:",type.Name);
            foreach (MethodInfo item in methods)
            {
                Console.WriteLine(item.Name);
            }
            Console.WriteLine("\n {0} class has following properties:", type.Name);
            foreach (PropertyInfo item in properties)
            {
                Console.WriteLine(item.Name);
            }
            Console.WriteLine("\n {0} class has following fields:", type.Name);
            foreach (FieldInfo item in fields)
            {
                Console.WriteLine(item.Name);
            }

            Console.ReadLine();
        }

        public class SampleReflection
        {
            public int age;
            public string name;
            public int Age
            {
                get
                {
                    return age;
                }
                set
                {
                    age = value;
                }
            }
            public string Name
            {
                get
                {
                    return name;
                }
                set
                {
                    name = value;
                }
            }
            public string GetName()
            {
                return name;
            }
            public int GetAge()
            {
                return age;
            }
      

        }
             
    }
}