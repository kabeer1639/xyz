﻿using System;

namespace BankDB
{
    public class CAccountsDB
    {
        #region Fields

        #endregion
        #region Property

        #endregion
        #region Methods

        #endregion
        #region Constructor

        #endregion
    }
}
