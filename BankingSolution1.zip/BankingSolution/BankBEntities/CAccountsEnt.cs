﻿using System;


namespace BankBEntities
{
    public class CAccountsEnt
    {
        #region Fields
        #endregion
        #region Property
        public int ACCOUNTNO { get; set; }
        [ValidateName("Name shoukd be in Capital Letters")]
        public string ACC_HOLD_NAME { get; set; }
        public string ACC_TYPE { get; set; }
        public string TRANS_TYPE { get; set; }
        public decimal AMOUNT { get; set; }
        //public decimal BALANCE { get; private set; }
        #endregion
        #region Methods

        #endregion
        #region Constructor
        public CAccountsEnt()
        {
            //BALANCE = AMOUNT;
        }
        public CAccountsEnt(int accno, string name,string acctype,string transtype,decimal amt)
        {
            ACCOUNTNO = accno;
            ACC_HOLD_NAME = name;
            ACC_TYPE = acctype;
            TRANS_TYPE = transtype;
            AMOUNT = amt;
            //BALANCE = AMOUNT;
        }
        #endregion
    }
}
