﻿using System;
using BankBEntities;
using BankClassLib;
using System.Collections.Generic;

namespace BankConsoleUI
{
    public class Program
    {
        static void emailAlert(CAccountsEnt entobj)
        {
            Console.WriteLine("Your balance has been changed");
        }
        static void Main(string[] args)
        {
            List<CAccountsEnt> listobj = new List<CAccountsEnt>();
            CAccountsEnt[] accentobj = new CAccountsEnt[1];
            for(int counter=0;counter<accentobj.Length;counter++)
            {
                accentobj[counter] = new CAccountsEnt();
            }
            for(int counter=0;counter<accentobj.Length;counter++)
            {
                Console.WriteLine("Enter Account No : ");
                accentobj[counter].ACCOUNTNO = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter Account Holder Name : ");
                accentobj[counter].ACC_HOLD_NAME = Console.ReadLine();
                Console.WriteLine("Enter Account Type : ");
                accentobj[counter].ACC_TYPE = Console.ReadLine();
                Console.WriteLine("Enter Transaction Type : ");
                accentobj[counter].TRANS_TYPE = Console.ReadLine();
                Console.WriteLine("Enter Amount : ");
                accentobj[counter].AMOUNT = Convert.ToDecimal(Console.ReadLine());
                MyFileWriter myFileWriter = new MyFileWriter();
                myFileWriter.mWriteToFile(accentobj[counter].ACCOUNTNO, accentobj[counter].ACC_HOLD_NAME, accentobj[counter].ACC_TYPE, accentobj[counter].TRANS_TYPE, accentobj[counter].AMOUNT);
            }
            listobj.AddRange(accentobj);
            foreach(var item in listobj)
            {
                Console.WriteLine("Account No is {0} ",item.ACCOUNTNO);
                Console.WriteLine("Account Holder Name is {0} ", item.ACC_HOLD_NAME);
                Console.WriteLine("Account Type is {0} ", item.ACC_TYPE);
                Console.WriteLine("Transaction Type is {0} ", item.TRANS_TYPE);
                Console.WriteLine("Amount is {0} ", item.AMOUNT);
                //Console.WriteLine("Your Balance is {0} ", item.BALANCE);
            }

            CSavingAccounts accobj = new CSavingAccounts(accentobj[0]);
            //restricting the listners
            accobj.onbalchange += new Onbalancechange(emailAlert);
            Console.WriteLine(accobj.BALANCE);
            //accentobj[0].AMOUNT=5000;
            try
            {
                accobj.mWithdraw(accentobj[0]);
            }
            catch(InsufficientFundException ife)
            {
                Console.WriteLine(ife.Message);
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            //Console.WriteLine(accobj.BALANCE);
        }
    }
}
