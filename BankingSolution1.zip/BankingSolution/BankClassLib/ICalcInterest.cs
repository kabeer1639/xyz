﻿using System;


namespace BankClassLib
{
    interface ICalcInterest
    {
        decimal interestcalc(int time, float rate, decimal amt);
    }
}
