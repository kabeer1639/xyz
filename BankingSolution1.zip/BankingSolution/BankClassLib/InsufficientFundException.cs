﻿using System;


namespace BankClassLib
{
    public class InsufficientFundException : ApplicationException
    {
        #region Constructor
        public InsufficientFundException() : base()
        {

        }
        public InsufficientFundException(string message) : base(message)
        {
            Console.WriteLine("InsufficientException : " + message);
        }
        public InsufficientFundException(string message,Exception innerException) : base(message,innerException)
        {
            Console.WriteLine("InsufficientException : " + message);
        }
        #endregion
    }
}
