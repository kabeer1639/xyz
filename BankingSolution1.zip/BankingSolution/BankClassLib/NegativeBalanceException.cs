﻿using System;


namespace BankClassLib
{
    class NegativeBalanceException : ApplicationException
    {
        #region Constructor
        public NegativeBalanceException() : base()
        {

        }
        public NegativeBalanceException(string message) : base(message)
        {
            Console.WriteLine("NegativeBalanceException : "+message);
        }
        public NegativeBalanceException(string message, Exception innerException) : base(message,innerException)
        {
            Console.WriteLine("NegativeBalanceException : "+message);
        }
        #endregion
    }
}
