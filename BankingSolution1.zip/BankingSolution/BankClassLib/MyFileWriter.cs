﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace BankClassLib
{
    public class MyFileWriter
    {
        StreamWriter MyWriter;
        FileStream filestream1;
        public MyFileWriter()
        {
            filestream1 = new FileStream(@"D:\Data.txt", FileMode.Append, FileAccess.Write);
            MyWriter = new StreamWriter(filestream1);
        }
        public void mWriteToFile(int accno, string name, string acctype,string transtype,decimal amt)
        {
            MyWriter.WriteLine(accno + "\n");
            MyWriter.WriteLine(name + "\n");
            MyWriter.WriteLine(acctype + "\n");
            MyWriter.WriteLine(transtype + "\n");
            MyWriter.WriteLine(amt + "\n");
            MyWriter.Flush();
            MyWriter.Close();
            filestream1.Close();
        }
    }
}
