﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PanExceptions;


namespace PanExceptions
{
    public class PanException : ApplicationException
    
    {

        public PanException()
            : base()
        {
        }

        public PanException(string message)
            : base(message)
        {
        }
        public PanException(string message, Exception innerException)
            : base(message, innerException)
        {
        }
    }
}
