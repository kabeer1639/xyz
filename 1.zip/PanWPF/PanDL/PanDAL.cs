﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PanEntities;
using PanExceptions;
using System.Data.Common;
using System.Data;
namespace PanDL
{
    public class PanDAL
    {

        public bool AddPanDAL(PANEntities newPan)
        {
            bool panAdded = false;
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "uspAddPan";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@ipv_PanID";
                param.DbType = DbType.Int32;
                param.Value = newPan.PAN_No;
                command.Parameters.Add(param);


                param = command.CreateParameter();
                param.ParameterName = "@ipv_vcPersonName";
                param.DbType = DbType.String;
                param.Value = newPan.Person_Name;
                command.Parameters.Add(param);



                param = command.CreateParameter();
                param.ParameterName = "@ipv_vcCity";
                param.DbType = DbType.String;
                param.Value = newPan.City;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@ipv_vcAddress";
                param.DbType = DbType.String;
                param.Value = newPan.Address;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@ipv_vcDate";
                param.DbType = DbType.String;
                param.Value = newPan.date_Of_Creation;
                command.Parameters.Add(param);

                int affectedRows = DataConnection.ExecuteNonQueryCommand(command);

                if (affectedRows > 0)
                    panAdded = true;
            }
            catch (DbException ex)
            {
                string errormessage;

                switch (ex.ErrorCode)
                {
                    case -2146232060:
                        errormessage = "Database Does NotExists Or AccessDenied";
                        break;
                    default:
                        errormessage = ex.Message;
                        break;
                }
                throw new PanException(errormessage);
            }
            return panAdded;

        }

        public List<PANEntities> GetAllPanDAL()
        {
            List<PANEntities> panList = null;
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "uspGetAllPan";



                DataTable dataTable = DataConnection.ExecuteSelectCommand(command);
                if (dataTable.Rows.Count > 0)
                {
                    panList = new List<PANEntities>();
                    for (int rowCounter = 0; rowCounter < dataTable.Rows.Count; rowCounter++)
                    {
                        PANEntities pan = new PANEntities();
                        pan.PAN_No = (int)dataTable.Rows[rowCounter][0];
                        pan.Person_Name = (string)dataTable.Rows[rowCounter][1];

                        pan.City = (string)dataTable.Rows[rowCounter][2];
                        pan.Address = (string)dataTable.Rows[rowCounter][3];
                        pan.date_Of_Creation = (DateTime)dataTable.Rows[rowCounter][4];
                        panList.Add(pan);
                    }
                }
            }
            catch (DbException ex)
            {
                throw new PanException(ex.Message);
            }
            return panList;
        }

        public PANEntities SearchPanDAL(int searchPanID)
        {
            PANEntities searchPan = null;
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "uspSearchPan";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@ipv_iPanID";
                param.DbType = DbType.Int32;
                param.Value = searchPanID;
                command.Parameters.Add(param);

                DataTable dataTable = DataConnection.ExecuteSelectCommand(command);
                if (dataTable.Rows.Count > 0)
                {
                    searchPan = new PANEntities();
                    searchPan.PAN_No = (int)dataTable.Rows[0][0];
                    searchPan.Person_Name = (string)dataTable.Rows[0][1];
                    searchPan.City = (string)dataTable.Rows[0][2];
                    searchPan.Address = (string)dataTable.Rows[0][3];
                    searchPan.date_Of_Creation = (DateTime)dataTable.Rows[0][4];

                }
            }
            catch (DbException ex)
            {
                throw new PanException(ex.Message);
            }
            return searchPan;
        }

        public bool UpdatePanDAL(PANEntities updatePan)
        {
            bool panUpdated = false;
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "uspUpdatePan";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@ipv_iPanID";
                param.DbType = DbType.Int32;
                param.Value = updatePan.PAN_No;
                command.Parameters.Add(param);


                param = command.CreateParameter();
                param.ParameterName = "@ipv_vcPersonName";
                param.DbType = DbType.String;
                param.Value = updatePan.Person_Name;
                command.Parameters.Add(param);


                param = command.CreateParameter();
                param.ParameterName = "@ipv_vcCity";
                param.DbType = DbType.String;
                param.Value = updatePan.City;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@ipv_vcAddress";
                param.DbType = DbType.String;
                param.Value = updatePan.Address;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@ipv_vcDate";
                param.DbType = DbType.String;
                param.Value = updatePan.date_Of_Creation;
                command.Parameters.Add(param);

                int affectedRows = DataConnection.ExecuteNonQueryCommand(command);

                if (affectedRows > 0)
                    panUpdated = true;
            }
            catch (DbException ex)
            {
                throw new PanException(ex.Message);
            }
            return panUpdated;

        }

        public bool DeletePanDAL(int deleteGuestID)
        {
            bool guestDeleted = false;
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "uspDeletePan";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@ipv_PanID";
                param.DbType = DbType.Int32;
                param.Value = deleteGuestID;
                command.Parameters.Add(param);

                int affectedRows = DataConnection.ExecuteNonQueryCommand(command);

                if (affectedRows > 0)
                    guestDeleted = true;
            }
            catch (DbException ex)
            {
                throw new PanException(ex.Message);
            }
            return guestDeleted;

        }
    }
}

   