using System;
public class Demo
{
            public static void Main()
              {
                  Console.WriteLine("Enter the name");
				  string Name = Console.ReadLine();
				  Console.WriteLine("You Entered:" +Name);
		   
              }
}