namespace MathLib
{
         public class MathClass
          {
		  public static int Add(int firstno,int secondno)
		  {
		    return firstno + secondno;
		  }
		  public static int Sub(int firstno,int secondno)
		  {
		    return firstno - secondno;
		  }
          }
}