using System;
public class HelloWorld
{
   //EXECUTION ENTRY POINT
  public static void Main()
  {
      //PRINTING MESSAGE
	  Console.WriteLine("HELLO WORLD!");
  }
}
