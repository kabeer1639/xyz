﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

/* Create the following procedure in Northwind Database
   Create Procedure uspProductDetails
   As
	  SELECT ProductID,ProductName,QuantityPerUnit,UnitPrice
	  FROM dbo.Products
*/

namespace IGATEPATNI.DEMOS.Day01
{
    public partial class Demo02 : Form
    {
        //string sqlConnectString = "Data Source=vm-iLearn;Initial Catalog=Northwind;User ID=sa;Password=igate@123";
        string sqlConnectString = "Data Source=punl08968;Initial Catalog=Northwind;User ID=sa;Password=igate@123";
        string sqlConnectString1 = "Data Source=vm-iLearn;Initial Catalog=AdventureWorks;User ID=sa;Password=igate@123";

        SqlConnection conn;
        SqlCommand cmdQuery;

        public Demo02()
        {
            InitializeComponent();
        }

        private void btnGet10MostExpProds_Click(object sender, EventArgs e)
        {
            conn = new SqlConnection(sqlConnectString);            
            cmdQuery = new SqlCommand("[Ten Most Expensive Products]",conn);
            cmdQuery.CommandType = CommandType.StoredProcedure;
                       
            conn.Open();

            SqlDataReader drProducts = cmdQuery.ExecuteReader(CommandBehavior.CloseConnection);
                      
            // Loop through the contents of the SqlDataReader object.
            // Display the results.     
            while(drProducts.Read())
            {
                lstTenMostExpProds.Items.Add(drProducts.GetString(0) + " " + drProducts.GetSqlMoney(1).ToDouble().ToString("c"));                   
            }
            drProducts.Close();
            conn.Close();
         }

        private void button1_Click(object sender, EventArgs e)
        {
            conn = new SqlConnection(sqlConnectString);
            conn.Open();
            SqlCommand cmdInsert = new SqlCommand();

            cmdInsert.Connection = conn;
            cmdInsert.CommandType = CommandType.StoredProcedure;
            cmdInsert.CommandText = "prcInsertCustomer";

            cmdInsert.Parameters.AddWithValue("@CID", txtCID.Text);
            cmdInsert.Parameters.AddWithValue("@FName", txtFN.Text);
            cmdInsert.Parameters.AddWithValue("@LName", txtLN.Text);
            cmdInsert.Parameters.AddWithValue("@Address", txtAdd.Text);
            cmdInsert.Parameters.AddWithValue("@City", txtCity.Text);
            cmdInsert.Parameters.AddWithValue("@Country", txtCountry.Text);
            cmdInsert.Parameters.AddWithValue("@Phone", txtPhone.Text);

            int iRowsAffected;

            iRowsAffected = cmdInsert.ExecuteNonQuery();

            if (iRowsAffected >= 1)
            {
                MessageBox.Show("Data Inserted");
            }
            else
            {
                MessageBox.Show("Error");
            }

            conn.Close();

        }

        private void btnOutputParam_Click(object sender, EventArgs e)
        {
            conn = new SqlConnection(sqlConnectString);
            conn.Open();
            
            SqlCommand command1 = new SqlCommand("RegionFind", conn);
            command1.CommandType = CommandType.StoredProcedure;

            SqlParameter Param1 = new SqlParameter("@RegionDescription", SqlDbType.NChar, 50);
            Param1.Direction = ParameterDirection.Output;
            SqlParameter Param2 = new SqlParameter("@RegionID", SqlDbType.Int);

            command1.Parameters.Add(Param1);
            command1.Parameters.Add(Param2);
            command1.Parameters["@RegionID"].Value = 4;
            command1.ExecuteNonQuery();
            string newRegionDescription = (string)command1.Parameters["@RegionDescription"].Value;
            MessageBox.Show(newRegionDescription);
        
            
        }      

       
    }
}