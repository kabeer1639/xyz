﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;

namespace AttributeEx
{
    //Attribute Usage
    [AttributeUsage(AttributeTargets.Class|AttributeTargets.Method,AllowMultiple =true)]
    class EmployeeAttribute:Attribute
    {
        private string _tax;
        
        private string _empname;

        public string TAX { get {return _tax; } set { _tax = value; } }
        
        public string EMPNAME { get {return _empname; } set { _empname = value; } }

        public EmployeeAttribute(string name)
        {
            
            
            EMPNAME = name;
        }
    }
    //Attributes
    [Employee("Taxable", EMPNAME = "Zeus")]
    [Employee("NonTaxable", EMPNAME = "John")]
    class Program
    {
        
        static void Main(string[] args)
        {   

            
            //print the attribute values using reflection
            Attribute[] attr1 = Attribute.GetCustomAttributes(typeof(Program));
            foreach (EmployeeAttribute item in attr1)
            {
                Console.WriteLine("{0}", item.EMPNAME);
            }

            //Attribute Information
            Console.WriteLine("Attributes Info");
            PropertyInfo[] pro = typeof(EmployeeAttribute).GetProperties();
            foreach (object item in attr1)
            {
                Console.WriteLine(item);
            }

            Console.ReadKey();
        }
    }
}
