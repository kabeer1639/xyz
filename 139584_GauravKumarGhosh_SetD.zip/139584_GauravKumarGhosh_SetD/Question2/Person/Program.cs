﻿using System;


namespace Sample
{
    //defination of delegate
    public delegate bool SearchDelegate(string name, string search);
   
    class Person
    {
        //Fields
        string _personName;
        string _searchcriteria;

        //Properties
        public string PERSONNAME { get {return _personName; } set {_personName=value; } }
        public string SEARCHCRITERIA { get {return _searchcriteria; } set { _searchcriteria = value; } }

        //constructors
        public Person()
        {

        }
        public Person(string name,string criteria)
        {
            PERSONNAME = name;
            SEARCHCRITERIA = criteria;
        }

        //method
        public bool SearchPersonRecord(string personName,string searchCriteria)
        {
            bool searchStringExists = personName.Contains(searchCriteria);
            return searchStringExists;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Person pr = new Person("Gaurav", "Capgemini");
            //using Delegates
            SearchDelegate del = new SearchDelegate(pr.SearchPersonRecord);
            bool value=del("Gaurav", "Gauav");
            Console.WriteLine("Using Delegate: "+value);           




            //using Anonymous Methods
            SearchDelegate delAnon = delegate (string name1, string search1)
            {
                bool searchStringExists = name1.Contains(search1);
                return searchStringExists;
            };
            bool anon=delAnon("Gaurav", "Gaurav");
            Console.WriteLine("Using Anonymous: "+anon);
            Console.ReadLine();
        }
    }
}
