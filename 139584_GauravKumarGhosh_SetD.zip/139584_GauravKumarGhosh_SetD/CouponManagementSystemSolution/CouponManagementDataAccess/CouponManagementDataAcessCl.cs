﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CouponManagementEntity;
using CouponManagementException;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;

namespace CouponManagementDataAccess
{
    public class CouponManagementDataAcessCl
    {
        //Static List to insert objects
        static List<CouponManagementEntityCl> listobj = new List<CouponManagementEntityCl>();

        //method to add a record
        public bool addcouponDAL(CouponManagementEntityCl coupon)
        {
            bool couponAdded = false;
            try
            {
                listobj.Add(coupon);
                couponAdded = true;
            }
            catch (Exception e)
            {
                
                throw new CouponManagementExceptionCl(e.Message);
            }
            return couponAdded;
        }

        //method to display List
        public List<CouponManagementEntityCl> GetAllCouponsDAL()
        {
            List<CouponManagementEntityCl> getcoupons = null;
            try
            {
                getcoupons = listobj;

            }
            catch (Exception e)
            {
                throw new CouponManagementExceptionCl(e.Message);
            }
            return getcoupons;
        }

        //method to search Coupon using lambda expression
        public CouponManagementEntityCl SearchCouponDAL(string empid)
        {
            CouponManagementEntityCl searchcoupon = null;
            try
            {
                searchcoupon = listobj.First(e => (e.EMPLOYEEID == empid));
            }
            catch (Exception e)
            {
                throw new CouponManagementExceptionCl(e.Message);
            }
            return searchcoupon;
        }

        //Update record
        public bool UpdateCouponDAL(CouponManagementEntityCl updateCoupon)
        {
            bool couponAdded = false;
            try
            {
                foreach (var item in listobj)
                {
                    if (item.EMPLOYEEID == updateCoupon.EMPLOYEEID)
                    {
                        item.EMPLOYEENAME = updateCoupon.EMPLOYEENAME;
                        item.ENROLLMENTNUM = updateCoupon.ENROLLMENTNUM;
                        item.ENROLLMENTDATE = DateTime.Now;
                        couponAdded = true;
                    }
                }
                
            }
            catch (Exception e)
            {
                
                throw new CouponManagementExceptionCl(e.Message);
            }
            return couponAdded;
        }

        
        //method to serialize
        public bool serializedataDAL()
        {
            List<CouponManagementEntityCl> listcoupon=listobj;
            bool serialize = false;
            FileStream fileStream = new FileStream("Employee.dat", FileMode.Create);
            BinaryFormatter sf1 = new BinaryFormatter();
            try
            {
                foreach (CouponManagementEntityCl coupon in listcoupon)
                {
                    sf1.Serialize(fileStream, coupon);
                }
                serialize = true;
            }
            catch(Exception e)
            {
                throw new CouponManagementExceptionCl(e.Message);
            }
            fileStream.Close();
            return serialize;
        }


        //method to deserealize
        public static ICollection<CouponManagementEntityCl> desearilizeDAL<CouponManagementEntityCl>(FileStream filestream)
        {
            BinaryFormatter sf1 = new BinaryFormatter();
            List<CouponManagementEntityCl> getlist = new List<CouponManagementEntityCl>();
            try
            {
                while(filestream.Position != filestream.Length)
                {
                    var deserealized = (CouponManagementEntityCl)sf1.Deserialize(filestream);
                    getlist.Add(deserealized);
                }
            }
            catch (Exception e)
            {
                throw new CouponManagementExceptionCl(e.Message);
            }
            return getlist;
        }
    }
}
