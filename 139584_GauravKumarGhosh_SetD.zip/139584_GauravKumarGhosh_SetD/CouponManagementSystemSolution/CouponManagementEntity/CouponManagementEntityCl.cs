﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CouponManagementEntity
{
    [Serializable]
    public class CouponManagementEntityCl
    {
        #region Fields
        private string _enrollmentNo;
        private string _employeeID;
        private string _employeeName;
        private DateTime _enrollmentDate;
        #endregion

        #region Property
        public string ENROLLMENTNUM { get {return _enrollmentNo; } set {_enrollmentNo=value; } }
        public string EMPLOYEEID { get {return _employeeID; } set { _employeeID = value; } }
        public string EMPLOYEENAME { get { return _employeeName; } set { _employeeName = value; } }
        public DateTime ENROLLMENTDATE { get { return _enrollmentDate; } set { _enrollmentDate = value; } }
        #endregion

        #region Constructor
        public CouponManagementEntityCl()
        {

        }
        public CouponManagementEntityCl(string enrollno,string empid,string empname,DateTime enrollmentdate)
        {
            ENROLLMENTNUM = enrollno;
            EMPLOYEEID = empid;
            EMPLOYEENAME = empname;
            ENROLLMENTDATE = enrollmentdate;
        }
        #endregion

        #region Methods
        #endregion
    }
}
