﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CouponManagementEntity;
using System.Text.RegularExpressions;
using CouponManagementException;
using CouponManagementDataAccess;

namespace CouponManagementBusiness
{
    public class CouponManagementBusinessCl
    {
        //method to check Validation
        private static bool ValidateCoupon(CouponManagementEntityCl coupon)
        {
            bool valid = true;
            StringBuilder sb = new StringBuilder();
            if (coupon.ENROLLMENTNUM.Length != 10)
            {
                valid = false;
                sb.Append(Environment.NewLine + "Invalid Enrollment Number");
            }
            if(!Regex.IsMatch(coupon.ENROLLMENTNUM, @"^\d+$"))
            {
                valid = false;
                sb.Append(Environment.NewLine + "Enrollment Number must be of type number");
            }
            if (coupon.EMPLOYEEID.Length != 6)
            {
                valid = false;
                sb.Append(Environment.NewLine + "Invalid Employee ID");
            }
            if (!Regex.IsMatch(coupon.EMPLOYEEID, @"^\d+$"))
            {
                valid = false;
                sb.Append(Environment.NewLine + "Employee ID must be of type number");
            }
            if (!Regex.IsMatch(coupon.EMPLOYEENAME, @"^[a-zA-Z]+$"))
            {
                valid = false;
                sb.Append(Environment.NewLine + "Employee Name must contain only alphabets");
            }
            if (coupon.EMPLOYEEID == string.Empty)
            {
                valid = false;
                sb.Append(Environment.NewLine + "Employee ID cannot be blank");
            }
            if (coupon.ENROLLMENTNUM == string.Empty)
            {
                valid = false;
                sb.Append(Environment.NewLine + "Enrollment number cannot be blank");
            }
            if (coupon.EMPLOYEENAME == string.Empty)
            {
                valid = false;
                sb.Append(Environment.NewLine + "Employee Name cannot be blank");
            }

           
            if (valid == false)
            {
                throw new CouponManagementExceptionCl(sb.ToString());
            }
            return valid;
        }

        //method to add record
        public static bool AddCoupon(CouponManagementEntityCl coupon)
        {
            bool couponadded = false;
            try
            {
                if (ValidateCoupon(coupon))
                {
                    CouponManagementDataAcessCl dal = new CouponManagementDataAcessCl();
                    couponadded = dal.addcouponDAL(coupon);
                }
            }
            catch (CouponManagementExceptionCl)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return couponadded;
        }

        //method to display list
        public static List<CouponManagementEntityCl> GetAllCouponsBL()
        {

            List<CouponManagementEntityCl> couponList = null;
            try
            {
                CouponManagementDataAcessCl couponDAL = new CouponManagementDataAcessCl();
                couponList = couponDAL.GetAllCouponsDAL();
            }
            catch (CouponManagementExceptionCl ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return couponList;
        }

        //method to search Coupon
        public static CouponManagementEntityCl SearchCouponBL(string searchEmployeeID)
        {
            CouponManagementEntityCl searchCoupon = null;
            try
            {
                CouponManagementDataAcessCl couponDAL = new CouponManagementDataAcessCl();
                searchCoupon = couponDAL.SearchCouponDAL(searchEmployeeID);
            }
            catch (CouponManagementExceptionCl ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchCoupon;

        }

        //method to update record
        public static bool UpdateCouponBL(CouponManagementEntityCl updateCoupon)
        {
            bool couponUpdated = false;
            try
            {
                if (ValidateCoupon(updateCoupon))
                {
                    CouponManagementDataAcessCl couponDAL = new CouponManagementDataAcessCl();
                    couponUpdated = couponDAL.UpdateCouponDAL(updateCoupon);
                }
            }
            catch (CouponManagementExceptionCl)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return couponUpdated;
        }

        //method to serialize
        public static bool serializedataBL()
        {
            bool serialize = false;
            try
            {
                CouponManagementDataAcessCl couponDAL = new CouponManagementDataAcessCl();
                serialize = couponDAL.serializedataDAL();
            }
            catch (CouponManagementExceptionCl)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return serialize;
        }
       
       
    }
}
