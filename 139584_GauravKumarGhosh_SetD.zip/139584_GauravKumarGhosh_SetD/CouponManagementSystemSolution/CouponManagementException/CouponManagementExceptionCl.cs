﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CouponManagementException
{
    public class CouponManagementExceptionCl:ApplicationException
    {
        //Exception Constructors
        public CouponManagementExceptionCl():base()
        {

        }
        public CouponManagementExceptionCl(string message):base(message)
        {

        }
        public CouponManagementExceptionCl(string message,Exception innerException):base(message,innerException)
        {

        }
    }
}
