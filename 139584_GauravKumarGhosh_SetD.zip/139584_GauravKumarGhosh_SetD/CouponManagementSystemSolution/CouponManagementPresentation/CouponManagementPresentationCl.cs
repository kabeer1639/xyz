﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CouponManagementEntity;
using CouponManagementBusiness;
using CouponManagementException;
using CouponManagementDataAccess;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace CouponManagementPresentation
{
    class CouponManagementPresentationCl
    {
        static void Main(string[] args)
        {
            int choice;
            //Menu Driven Display
            do
            {
                DisplayMenu();
                Console.WriteLine("Enter your Choice:");
                choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        AddCoupon();
                        break;
                    case 2:
                        ListAllCoupons();
                        break;
                    case 3:
                        SearchCouponByID();
                        break;
                    case 4:
                        UpdateCoupon();
                        break;
                    
                    case 5:
                        serializemethod();
                        break;
                    case 6:
                        //deserialization of records from file
                        FileStream filestream = new FileStream("Employee.dat",FileMode.Open);           //opening file stream
                        List<CouponManagementEntityCl> newlist = new List<CouponManagementEntityCl>(CouponManagementDataAcessCl.desearilizeDAL<CouponManagementEntityCl>(filestream));
                        foreach(var item in newlist) //print all the deserialized values
                        {
                            Console.WriteLine("Employee ID:"+item.EMPLOYEEID);
                            Console.WriteLine("Employee Name"+item.EMPLOYEENAME);
                            Console.WriteLine("Enrollment Date"+item.ENROLLMENTDATE);
                            Console.WriteLine("Enrollment Number"+item.ENROLLMENTNUM);
                        }
                        break;
                    case 7:
                        return;
                    default:
                        Console.WriteLine("Invalid Choice");
                        break;
                }
            } while (choice != -1);
        }
        private static void DisplayMenu()
        {
            Console.WriteLine("\n***********Coupon Management System Menu***********");
            Console.WriteLine("1. Add Coupon");
            Console.WriteLine("2. List All coupon");
            Console.WriteLine("3. Search Coupon by EmployeeID");
            Console.WriteLine("4. Update Coupon");
            Console.WriteLine("5. Serialize");
            Console.WriteLine("6. Deserealize");
            Console.WriteLine("7. Exit");
            Console.WriteLine("******************************************\n");

        }

        //method to add a record
        private static void AddCoupon()
        {
            try
            {
                Console.WriteLine("Enter Enrollment Number :");
                string enrollnum = Console.ReadLine();
                Console.WriteLine("Enter Employee ID :");
                string empid = Console.ReadLine();
                Console.WriteLine("Enter Employee Name :");
                string empname = Console.ReadLine();
                CouponManagementEntityCl coupon = new CouponManagementEntityCl(enrollnum,empid, empname,DateTime.Now);
                bool couponAdded = CouponManagementBusinessCl.AddCoupon(coupon);
                if (couponAdded)
                    Console.WriteLine("Coupon Added");
                else
                    Console.WriteLine("Coupon not Added");
            }
            catch (CouponManagementExceptionCl ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //method to display
        private static void ListAllCoupons()
        {
            try
            {
                List<CouponManagementEntityCl> couponList = CouponManagementBusinessCl.GetAllCouponsBL();
                if (couponList != null)
                {
                    Console.WriteLine("******************************************************************************");
                    Console.WriteLine("EnrollmentID\tEmployeeID\tEmployee Name\tEnrollment Date");
                    Console.WriteLine("******************************************************************************");
                    foreach (var item in couponList)
                    {
                        Console.WriteLine("{0}\t{1}\t\t\t{2}\t{3}", item.ENROLLMENTNUM, item.EMPLOYEEID, item.EMPLOYEENAME,item.ENROLLMENTDATE);
                    }
                    Console.WriteLine("******************************************************************************");

                }
                else
                {
                    Console.WriteLine("No Coupon Details Available");
                }
            }
            catch (CouponManagementExceptionCl ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //method to search
        private static void SearchCouponByID()
        {
            try
            {
                string searchEmployeeID;
                Console.WriteLine("Enter EmployeeID to Search:");
                searchEmployeeID = Console.ReadLine();
                CouponManagementEntityCl searchCoupon = CouponManagementBusinessCl.SearchCouponBL(searchEmployeeID);
                if (searchCoupon != null)
                {
                    Console.WriteLine("******************************************************************************");
                    Console.WriteLine("EnrollmentID\tEmployeeID\tEmployee Name\tEnrollment Date");
                    Console.WriteLine("******************************************************************************");
                    Console.WriteLine("{0}\t{1}\t{2}\t{3}", searchCoupon.ENROLLMENTNUM, searchCoupon.EMPLOYEEID, searchCoupon.EMPLOYEENAME, searchCoupon.ENROLLMENTDATE);
                    Console.WriteLine("******************************************************************************");
                }
                else
                {
                    Console.WriteLine("No Coupon Details Available");
                }

            }
            catch (CouponManagementExceptionCl ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //method to update
        private static void UpdateCoupon()
        {
            try
            {
                string updateEmpID;
                Console.WriteLine("Enter EmployeeID to Update Details:");
                updateEmpID = Console.ReadLine();
                CouponManagementEntityCl updatedCoupon = CouponManagementBusinessCl.SearchCouponBL(updateEmpID);
                if (updatedCoupon == null)
                {
                    Console.WriteLine("No matching Employee ID");
                }

                else
                {
                    CouponManagementEntityCl tempobj = new CouponManagementEntityCl();
                    tempobj.EMPLOYEEID = updateEmpID;
                    Console.WriteLine("Update Enrollment Number :");
                    tempobj.ENROLLMENTNUM = Console.ReadLine();
                    Console.WriteLine("Update Employee Name :");
                    tempobj.EMPLOYEENAME = Console.ReadLine();
                    bool couponUpdated = CouponManagementBusinessCl.UpdateCouponBL(tempobj);
                    if (couponUpdated)
                        Console.WriteLine("Coupon Details Updated");
                    else
                        Console.WriteLine("Coupon Details not Updated ");
                }

            }
            catch (CouponManagementExceptionCl ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

      //method to serialize
        private static void serializemethod()
        {
            bool serialize = false;
            try
            {
                serialize = CouponManagementBusinessCl.serializedataBL();
            }
            catch(Exception e)
            {
                throw new CouponManagementExceptionCl(e.Message);
            }
            if (serialize)
            {
                Console.WriteLine("Serialization Successful");
            }
            else
            {
                Console.WriteLine("Serialization Not Successful");
            }
        }
       
    }
}
