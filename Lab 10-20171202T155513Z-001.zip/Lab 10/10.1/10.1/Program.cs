﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _10._1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter two numbers:");
            int n1 = Convert.ToInt32(Console.ReadLine());
            int n2=  Convert.ToInt32(Console.ReadLine());
            ArithmeticOperations ao = new ArithmeticOperations();
            MathDel md = new MathDel(ao.Addition);



            try
            {
                int choice = 0;
                do
                {
                    Console.WriteLine("1.Addition \n2.Subtractiion \n3.Division \n4. Multiplication \n5.Find Maximum\n6.Exit");
                    Console.WriteLine();
                    Console.WriteLine("Enter your Choice:");
                    choice = Convert.ToInt32(Console.ReadLine());
                    switch(choice)
                    {
                        case 1:
                            ao.Addition(n1, n2);
                            break;

                        case 2:
                            ao.Subtraction(n1,n2);
                            break;

                        case 3:
                            ao.Division(n1,n2);
                            break;

                        case 4:
                            ao.Multiplication(n1,n2);
                            break;

                        case 5:
                            ao.Max(n1,n2);
                            break;
                        case 6:
                            
                            break;
                        default:
                            Console.WriteLine("Invalid choice.Please try again");
                            break;

                    }
                } while (choice !=6);
            }
            catch (FormatException ex)
            {

                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {

                Console.WriteLine(ex.Message);
            }

            md += new MathDel(ao.Subtraction);
            md += new MathDel(ao.Division);
            md += new MathDel(ao.Multiplication);
            md += new MathDel(ao.Max);

            md.Invoke(n1, n2);



           
        }
    }
}
