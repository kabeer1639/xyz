﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _10._1
{
    delegate void MathDel(int n1, int n2);
    public class ArithmeticOperations
    {
        public void Addition(int num1, int num2)
        {
            int result = num1 + num2;
            Console.WriteLine(result);

        }
        public void Subtraction(int num1, int num2)
        {
            int result = num1 - num2;
            Console.WriteLine(result);

        }
        public void Division(int num1, int num2)
        {
            int result = num1 / num2;
            Console.WriteLine(result);

        }
        public void Multiplication(int num1, int num2)
        {
            int result = num1 * num2;
            Console.WriteLine(result);

        }
        public void Max(int num1, int num2)
        {
            if(num1 > num2)
                Console.WriteLine(num1);
        }

    }
}
